<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rent extends Model
{
	public $table="rent";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'city',
        'category',
        'bedrooms',
        'bathrooms',
        'area',
        'face',
        'floor',
        'liftfacility',
        'description',
        'picture'
    ];

    public function category()
{
return $this->hasMany('App\category','id','id');
}
}


