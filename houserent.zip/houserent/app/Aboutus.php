<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutus extends Model
{
     public $table="Aboutuses";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'title',
        
        'description'

];
}
