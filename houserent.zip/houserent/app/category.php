<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category extends Model
{
	public $table="category";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'name'
];
public function Rent()
{
return $this->belongsTo('App\Rent');
}

}
