<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class service extends Model
{
      public $table="Services";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'title',
        
        'description'

];
}
