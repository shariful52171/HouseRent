<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Propose extends Model
{
    public $table="proposes";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'rent_id',
        'name',
        'email',
        'contact',
        'description'
        
    ];
}
