<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carausel extends Model
{
    public $table="carausel";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'title',
        'category',
        'location',
        'picture'
        ];
}
