<?php

namespace App\Http\Controllers;
use App\Rent;
use App\aboutus;
use App\contactus;
use Illuminate\Http\Requests;
use Request;
use App\Http\Controllers\Controller;
use DB;

class MessageController extends Controller
{
    
    public function index()
    {
        $mdatas=Message::all();
       return view('Message.index')->with('mdatas',$mdatas);
    }

    
    public function create()
    {
        //$cdatas=Company::all();
 $footerslide1 = DB::table('carausel')->distinct()->get();
        

        return view ('Project.contact')->with(compact('footerslide1'));

    }




    
    public function store(Request $request)
    {


  // this is our email function


        

//         $from = '<azharuddinfeni1991@gmail.com>';
// $to = '<taohidulalam@yahoo.com>';
// $subject = 'Hi!';
// $body = "Hi,\n\nHow are you?";

// //mail("$to","My subject","$body");
// $headers = "From: azharuddinfeni1991@gmail.com" . "\r\n" ."CC: somebodyelse@example.com";

// mail($to,$subject,$body,$headers);












                        // require "Mail.php";

                            // $host    = "smtp.gmail.com";
                            // $port    =  "587";
                            // $user    = "azharuddinfeni1991@gmail.com";
                            // $pass    = "azhar@uddin71";
                            // $headers = array("From"=> $from, "To"=>$to, "Subject"=>$subject);
                            // $smtp    = @Mail::factory("smtp", array("host"=>$host, "port"=>$port, "auth"=> true, "username"=>$user, "password"=>$pass));
                            // $mail    = @$smtp->send($to, $headers, $body);

                            // if (PEAR::isError($mail)){
                            //     echo "error: {$mail->getMessage()}";
                            // } else {
                            //     echo "Message sent";
                            // }






















$footerslide1 = DB::table('carausel')->distinct()->get();

        $mdatas=Request::all();
        contactus::create($mdatas);
        return view('Project.success')->with(compact('footerslide1'));
    }

    
    public function show($id)
    {
        $mdata=Message::where('id', '=', $id)->first();
         
         return view('Message.show',compact('mdata'));
    }

    
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        //
    }

    
    public function destroy($id)
    {
        Message::find($id)->delete();
         return redirect('message');
    }


     public function About()
    {
 $footerslide1 = DB::table('carausel')->distinct()->get();

        $AComments=Aboutus::all();
        $des = aboutus::select('description')->distinct()->get();

         //$Proposes = DB::table('Proposes')->paginate(2);

       return view('Project.aboutus')->with('Aboutus',$AComments)->with(compact('footerslide1'))->with(compact('des'));
    }


    
}
