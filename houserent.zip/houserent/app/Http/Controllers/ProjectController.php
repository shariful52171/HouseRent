<?php
//use Illuminate\Support\Facades\DB;
namespace App\Http\Controllers;
use DB;
use App\aboutus;
use App\About;
use App\Rent;
use App\category;
use App\Propose;

//use Illuminate\Http\Request;
use Request;

class ProjectController extends Controller
{
    public function index()    {

   //       $book=Book::where('slno', '=', $id)->first();
   // return view('book.show',compact('book'));

    	$rentData = DB::table('rent')->get();

        $singlData1 = Rent::select('picture')->distinct()->get();

    	$user = Rent::select('city')->distinct()->get();
    	$bed = Rent::select('bedrooms')->distinct()->get();
    	$bath = Rent::select('bathrooms')->distinct()->get();
    	$cat = category::select('id','name')->distinct()->get();
        $CommentsData = DB::table('comments')->get();
        $footerslide1 = DB::table('carausel')->distinct()->get();

    // $des = aboutus::select('description')->distinct()->get();   


        //$user2 = comment::select('picture')->distinct()->get();
        return view('Project.index')
        		->with(compact('user'))
        		->with(compact('cat'))
        		->with(compact('bed'))
                ->with(compact('bath'))
        		->with(compact('singlData1'))
        		->with(compact('rentData'))
                ->with(compact('CommentsData'))
                //->with(compact('des'))
                ->with(compact('footerslide1'));
               
       

    

    }
    public function showdetails($id){
         $footerslide1 = DB::table('carausel')->distinct()->get();

        $showdetails=Rent::where('id', '=', $id)->first();
        //echo $footerslide1 ;
        return view('Project.showdetails')->with(compact('showdetails'))->with(compact('footerslide1'));
    }

    public function create()
    {
         $footerslide1 = DB::table('carausel')->distinct()->get();
        
        
        return view ('Proposes.Propose')->with(compact('footerslide1'));
    }



     public function store(Request $request)
    {
        //return "you are fired";
  $mdatas=Request::all();
   Propose::create($mdatas);
   //return redirect('Proposes');




       // $mdatas=Request::all();
       //return  $mdatas;
        //$from = '<azharuddinfeni1991@gmail.com>';
            $to = $mdatas['email'];
            $subject =$mdatas['contact'];
            $body =$mdatas['description'];
            
            //mail("$to","My subject","$body");
            $headers = "From:info@elevensunity.com";
            if(mail($to,$subject,$body,$headers))
            {
            
            echo "sent";
            }
            else
            echo "Not sent";
    }


public function getSearchfeebyname()
    {
        
        $keyword=\Input::get('q');
        $stidnames=Rent::pluck('city','id');
        //$Fees=Students::find($keyword)->Fees()->get();
        $category=\DB::table('Rent AS a')->leftJoin('category AS b', function($join){$join->on('a.id','=','b.id');
    })->where('a.id','=',$keyword)->select('a.id','a.city','a.category','a.bedrooms','a.bathrooms','a.area','a.face','a.floor','a.liftfacility','a.description','b.id','b.name')->get();
   return view('Project.searchfeebyname',compact('stidnames'))->with('category',$category);
    }

   
}
