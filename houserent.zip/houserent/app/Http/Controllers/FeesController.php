<?php namespace App\Http\Controllers;
use App\Fees;
use App\Students;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Request;
class FeesController extends Controller {

	
	public function index()
	{
		$Fees=Fees::all();
	   return view('Fees.index')->with('Fees',$Fees);
	}

	
	public function create()
	{
		$stidnames=Students::pluck('name','id');
		return view('Fees.create',compact('stidnames'));
	}

	
	public function store()
	{
		$Fees=Request::all();
   Fees::create($Fees);
   return redirect('Fees');
	}

	
	public function show($id)
	{
		 $Fees=Fees::where('voucherno', '=', $id)->first();
   return view('Fees.show',compact('Fees'));
	}

	
	public function edit($id)
	{
		 $Fees=Fees::find($id);
		return view('Fees.edit',compact('Fees'));
	}

	
	public function update($id)
{
      $FeesUpdate=Request::all();
   $Fees=Fees::find($id);
   $Fees->update($FeesUpdate);
   return redirect('Fees');
}

	
	public function destroy($id)
	{
		 Fees::find($id)->delete();
   return redirect('Fees');
	}

}
