<?php

namespace App\Http\Controllers;

use App\service;

use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Request;
use App\contactus;

class ServicesController extends Controller
{
   public function index()
    {
        $Service=service::all();
      //return 'heello0';
         $Service= DB::table('services')->paginate(2);

       return view('Service.index')->with('Service',$Service);
    }

    
    public function create()
    {
        return view('Service.create');
    }

    
    public function store()
    {
        $Service=Request::all();
   Service::create($Service);
   return redirect('service');
    }

    
    public function show($id)
    {
         $Service=Service::where('id', '=', $id)->first();
         //return $Service;
   return view('Service.show',compact('Service'));

    }

    
    public function edit($id)
    {
         $Service=Service::find($id);
        return view('Service.edit',compact('Service'));
    }

    
    public function update($id)
{
      $ServiceUpdate=Request::all();
   $Service=Service::find($id);
   $Service->update($ServiceUpdate);
   return redirect('service');
}

    
    public function destroy($id)
    {
         Service::find($id)->delete();
   return redirect('service');
    }
}

