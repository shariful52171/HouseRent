<?php namespace App\Http\Controllers;
use App\Students;
use App\Rent;
//use DB;

//use App\Rent;
use App\category;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
class StudentsController extends Controller {

	
	public function index()
	{
		$Students=Students::all();
		 $Students = DB::table('Students')->paginate(2);

	   return view('Students.index')->with('Students',$Students);
	}

	
	public function create()
	{
		return view('Students.create');
	}

	
	public function store()
	{
		$Students=Request::all();
   Students::create($Students);
   return redirect('Students');
	}
	public function getSearch()
	{
		$keyword=\Input::get('q');
		$Students=Students::where('id','=',$keyword)->get();
   return view('Students.search')->with('Students',$Students);
	}

	public function getSearchfee()
	{
		$keyword=\Input::get('q');	

		$Fees=Students::find($keyword)->Fees()->get();

return view('Students.searchfee')->with('Fees', $Fees);


		//$Fees=Students::find($keyword)->Fees()->get();
		$Fees=\DB::table('Students AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
   return view('Students.searchfee')->with('Fees',$Fees);
	}
	
public function showcon($city,$cat)
    {
    	$rentData=\DB::table('Rent')->where('city','=',$city)->where('category','=',$cat)->get();
 $singlData1 = Rent::select('picture')->distinct()->get();

//$rentData = DB::table('rent')->get();
 $CommentsData = DB::table('comments')->get();
 $footerslide1 = DB::table('carausel')->distinct()->get();

    	
    	$user = Rent::select('city')->distinct()->get();
    	$bed = Rent::select('bedrooms')->distinct()->get();
    	$bath = Rent::select('bathrooms')->distinct()->get();
    	$cat = category::select('id','name')->distinct()->get();

        return view('Project.index')
        		->with(compact('user'))
        		->with(compact('cat'))
        		->with(compact('bed'))
        		->with(compact('bath'))
                ->with(compact('CommentsData'))
                ->with(compact('footerslide1'))

        		->with(compact('singlData1'))
        		->with(compact('rentData'));



        
    }


public function getSearchfeebyname()
	{
		$keyword=\Input::get('q');
		$stidnames=Students::pluck('name','id');
		//$Fees=Students::find($keyword)->Fees()->get();
		$Fees=\DB::table('Students AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
   return view('Students.searchfeebyname',compact('stidnames'))->with('Fees',$Fees);
	}

	
	public function show($id)
	{
		 $Students=Students::where('id', '=', $id)->first();
   return view('Students.show',compact('Students'));
	}

	
	public function edit($id)
	{
		 $Students=Students::find($id);
		return view('Students.edit',compact('Students'));
	}

	
	public function update($id)
{
      $StudentsUpdate=Request::all();
   $Students=Students::find($id);
   $Students->update($StudentsUpdate);
   return redirect('Students');
}

	
	public function destroy($id)
	{
		 Students::find($id)->delete();
   return redirect('Students');
	}

}
