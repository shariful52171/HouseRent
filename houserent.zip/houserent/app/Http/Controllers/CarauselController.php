<?php 
namespace App\Http\Controllers;
use App\Carausel;
use App\Http\Requests;
use Request;
use App\Http\Controllers\Controller;


class CarauselController extends Controller {

    
    public function index()
    {
        $Carausel=Carausel::all();
        
 return view('Carausel.index')->with('Carausel',$Carausel);
    }

    
    public function create()
    {
        return view('Carausel.create');
    }

    
    public function store()
    {
        $Carausel=Request::all();
   Carausel::create($Carausel);
   return redirect('Carausel');
    }
public function show($id)
    {
         $Carausel=Carausel::where('id', '=', $id)->first();
   return view('Carausel.show',compact('Carausel'));
    }
 
    
    public function edit($id)
    {
         $Carausel=Carausel::find($id);

        return view('Carausel.edit',compact('Carausel'));
    }

 public function update(Request $request, $id)
    {
         $CarauselUpdate=Request::all();
        $Carausel1=Carausel::find($id);
        $Carausel1->update($CarauselUpdate);


        $Carausel=Carausel::find($id);
        request()->validate(['picture'=>'required|image|mimes:jpeg,jpg,png,gif,svg|max:10048',]);
        $imageName = request()->picture->getClientOriginalName();
        request()->picture->move(public_path('carausel_images'),$imageName);
        $a1 = Carausel::where('id',$id)->first();
        $a1->picture = request()->picture->getClientOriginalName();
        $a1->save();
        return redirect('Carausel');
    } 
    


    
    public function destroy($id)
    {
         Carausel::find($id)->delete();
   return redirect('Carausel');
    }



}
