<?php namespace App\Http\Controllers;
use App\Rent;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
class RentController extends Controller {

	
	public function index()
	{
		$Rent=Rent::all();
		 //$Rent = DB::table('Rent')->paginate(2);

	   return view('Rent.index')->with('Rent',$Rent);
	}

	
	public function create()
	{
		return view('Rent.create');
	}

	
	public function store()
	{
		$Rent=Request::all();
   Rent::create($Rent);
   return redirect('Rent');
	}
// 	public function getSearch()
// 	{
// 		$keyword=\Input::get('q');
// 		$Rent=Rent::where('id','=',$keyword)->get();
//    return view('Rent.search')->with('Rent',$Rent);
// 	}

// 	public function getSearchfee()
// 	{
// 		$keyword=\Input::get('q');

// 		$Fees=Rent::find($keyword)->Fees()->get();
// return view('Rent.searchfee')->with('Fees', $Fees);


// 		//$Fees=Rent::find($keyword)->Fees()->get();
// 		$Fees=\DB::table('Rent AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
// 	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
//    return view('Rent.searchfee')->with('Fees',$Fees);
// 	}
	



// public function getSearchfeebyname()
// 	{
// 		$keyword=\Input::get('q');
// 		$stidnames=Rent::pluck('name','id');
// 		//$Fees=Rent::find($keyword)->Fees()->get();
// 		$Fees=\DB::table('Rent AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
// 	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
//    return view('Rent.searchfeebyname',compact('stidnames'))->with('Fees',$Fees);
// 	}

	
	public function show($id)
	{
		 $Rent=Rent::where('id', '=', $id)->first();
   return view('Rent.show',compact('Rent'));
	}

	
	public function edit($id)
	{
		 $Rent=Rent::find($id);
		return view('Rent.edit',compact('Rent'));
	}

	
	public function update($id)
{
      $RentUpdate=Request::all();
   $Rent=Rent::find($id);
   $Rent->update($RentUpdate);
   return redirect('Rent');
}

	
	public function destroy($id)
	{
		 Rent::find($id)->delete();
   return redirect('Rent');
	}

}
