<?php namespace App\Http\Controllers;
use App\Category;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
class CategoryController extends Controller {

	
	public function index()
	{
		$Category=Category::all();
		 $Category = DB::table('Category')->paginate(2);

	   return view('Category.index')->with('Category',$Category);
	}

	
	public function create()
	{
		return view('Category.create');
	}

	
	public function store()
	{
		$Category=Request::all();
   Category::create($Category);
   return redirect('Category');
	}
// 	public function getSearch()
// 	{
// 		$keyword=\Input::get('q');
// 		$Category=Category::where('id','=',$keyword)->get();
//    return view('Category.search')->with('Category',$Category);
// 	}

// 	public function getSearchfee()
// 	{
// 		$keyword=\Input::get('q');

// 		$Fees=Category::find($keyword)->Fees()->get();
// return view('Category.searchfee')->with('Fees', $Fees);


// 		//$Fees=Category::find($keyword)->Fees()->get();
// 		$Fees=\DB::table('Category AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
// 	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
//    return view('Category.searchfee')->with('Fees',$Fees);
// 	}
	



// public function getSearchfeebyname()
// 	{
// 		$keyword=\Input::get('q');
// 		$stidnames=Category::pluck('name','id');
// 		//$Fees=Category::find($keyword)->Fees()->get();
// 		$Fees=\DB::table('Category AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
// 	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
//    return view('Category.searchfeebyname',compact('stidnames'))->with('Fees',$Fees);
// 	}

	
	public function show($id)
	{
		 $Category=Category::where('id', '=', $id)->first();
   return view('Category.show',compact('Category'));
	}

	
	public function edit($id)
	{
		 $Category=Category::find($id);
		return view('Category.edit',compact('Category'));
	}

	
	public function update($id)
{
      $CategoryUpdate=Request::all();
   $Category=Category::find($id);
   $Category->update($CategoryUpdate);
   return redirect('Category');
}

	
	public function destroy($id)
	{
		 Category::find($id)->delete();
   return redirect('Category');
	}

}
