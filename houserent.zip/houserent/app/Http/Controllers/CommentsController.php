<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
class CommentsController extends Controller
{
   
    public function index()
    {
        $Comments=Comment::all();
    

       return view('Comments.index')->with('Comments',$Comments);
    }

    
    public function create()
    {
        return view('Comments.create');
    }

    
    public function store()
    {
        $Comments=Request::all();
   Comment::create($Comments);
   return redirect('Comments');
    }
public function show($id)
    {
         $Comments=Comment::where('id', '=', $id)->first();
   return view('Comments.show',compact('Comments'));
    }

    
    public function edit($id)
    {
         $Comments=Comment::find($id);
        return view('Comments.edit',compact('Comments'));
    }

    
    public function update($id)
{
      $CommentsUpdate=Request::all();
   $Comments=Comment::find($id);
   $Comments->update($CommentsUpdate);
   return redirect('Comments');
}






    
    public function destroy($id)
    {
         Comment::find($id)->delete();
   return redirect('Comments');
    }

}
