<?php

namespace App\Http\Controllers;
use App\Rent;
use App\Http\Requests;
use Request;
use App\Http\Controllers\Controller;

//use Illuminate\Http\Request;


class RentUploadController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function index()
    {
        $student=Rent::all();       
        return view('Rent.index')->with('Rent',$student);
    }

    public function edit($id)
    {
        $student=Rent::find($id);
        return view('RentUpload.edit',compact('student'));
    }
   
    public function update(Request $request, $id)
    {
        request()->validate(['picture'=>'required|image|mimes:jpeg,jpg,png,gif,svg|max:10048',]);
        $imageName = request()->picture->getClientOriginalName();
        request()->picture->move(public_path('images'),$imageName);
        $a1 = Rent::where('id',$id)->first();
        $a1->picture = request()->picture->getClientOriginalName();
        $a1->save();
        return redirect('RentUpload');
    } 





    





}
