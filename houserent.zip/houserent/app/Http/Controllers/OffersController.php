<?php namespace App\Http\Controllers;
use App\Offers;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
class OffersController extends Controller {

	
	public function index()
	{
		$Offers=Offers::all();
		 $Offers = DB::table('Offers')->paginate(2);

	   return view('Offers.index')->with('Offers',$Offers);
	}

	
	public function create()
	{
		return view('Offers.create');
	}

	
	public function store()
	{
		$Offers=Request::all();
   Offers::create($Offers);
   return redirect('Offers');
	}
	public function getSearch()
	{
		$keyword=\Input::get('q');
		$Offers=Offers::where('id','=',$keyword)->get();
   return view('Offers.search')->with('Offers',$Offers);
	}

	public function getSearchfee()
	{
		$keyword=\Input::get('q');

		$Fees=Offers::find($keyword)->Fees()->get();
return view('Offers.searchfee')->with('Fees', $Fees);


		//$Fees=Offers::find($keyword)->Fees()->get();
		$Fees=\DB::table('Offers AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
   return view('Offers.searchfee')->with('Fees',$Fees);
	}
	



public function getSearchfeebyname()
	{
		$keyword=\Input::get('q');
		$stidnames=Offers::pluck('name','id');
		//$Fees=Offers::find($keyword)->Fees()->get();
		$Fees=\DB::table('Offers AS a')->leftJoin('Fees AS b', function($join){$join->on('a.id','=','b.id');
	})->where('a.id','=',$keyword)->select('a.id','a.name','a.class','b.voucherno','b.date','b.amount')->get();
   return view('Offers.searchfeebyname',compact('stidnames'))->with('Fees',$Fees);
	}

	
	public function show($id)
	{
		 $Offers=Offers::where('id', '=', $id)->first();
   return view('Offers.show',compact('Offers'));
	}

	
	public function edit($id)
	{
		 $Offers=Offers::find($id);
		return view('Offers.edit',compact('Offers'));
	}

	
	public function update($id)
{
      $OffersUpdate=Request::all();
   $Offers=Offers::find($id);
   $Offers->update($OffersUpdate);
   return redirect('Offers');
}

	
	public function destroy($id)
	{
		 Offers::find($id)->delete();
   return redirect('Offers');
	}

}
