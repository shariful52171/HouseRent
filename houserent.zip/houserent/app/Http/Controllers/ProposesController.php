<?php

namespace App\Http\Controllers;
use App\Propose;

use Illuminate\Http\Request;

class ProposesController extends Controller
{
   public function index()
    {
        $Proposes=Propose::all();
         //$Proposes = DB::table('Proposes')->paginate(2);

       return view('Proposes.Propose')->with('Proposes',$Proposes);
    }

    
    public function create()
    {
        return view('Proposes.create');
    }

    
    
}
