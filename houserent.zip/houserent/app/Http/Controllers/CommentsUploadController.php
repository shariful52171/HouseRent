<?php

namespace App\Http\Controllers;
use App\Comment;
use App\Http\Requests;
use Request;
use App\Http\Controllers\Controller;

//use Illuminate\Http\Request;


class CommentsUploadController extends Controller
{
	public function index()
    {
        $student=Comment::all();       
        return view('Comments.index')->with('Comments',$student);
    }

    public function edit($id)
    {
        $student=Comment::find($id);
        return view('CommentsUpload.edit',compact('student'));
    }
   
    public function update(Request $request, $id)
    {
        request()->validate(['picture'=>'required|image|mimes:jpeg,jpg,png,gif,svg|max:10048',]);
        $imageName = request()->picture->getClientOriginalName();
        request()->picture->move(public_path('images'),$imageName);
        $a1 = Comment::where('id',$id)->first();
        $a1->picture = request()->picture->getClientOriginalName();
        $a1->save();
        return redirect('CommentsUpload');
    } 





    





}
