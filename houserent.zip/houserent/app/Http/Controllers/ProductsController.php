<?php namespace App\Http\Controllers;
use App\Products;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

use Request;
class ProductsController extends Controller {
public function __construct()
	{
		$this->middleware('auth:admin');
	}
	
	public function index()
	{
		$Products=Products::all();
		$Products = DB::table('Products')->paginate(2);
	   return view('Products.index')->with('Products',$Products);
	}

	
	public function create()
	{
		return view('Products.create');
	}

	
	public function store()
	{
		$Products=Request::all();
   Products::create($Products);
   return redirect('Products');
	}

	
	public function show($id)
	{
		 $Products=Products::where('id', '=', $id)->first();
   return view('Products.show',compact('Products'));
	}

	
	public function edit($id)
	{
		 $Products=Products::find($id);
		return view('Products.edit',compact('Products'));
	}

	
	public function update($id)
{
      $ProductsUpdate=Request::all();
   $Products=Products::find($id);
   $Products->update($ProductsUpdate);
   return redirect('Products');
}

	
	public function destroy($id)
	{
		 Products::find($id)->delete();
   return redirect('Products');
	}

}
