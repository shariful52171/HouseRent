<?php

namespace App\Http\Controllers;
 use DB;

use App\Rent;
use App\category;
use App\Propose;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    // public function index()
    // {
    //     return view('home');
    // }


   
 public function index()    {

   //       $book=Book::where('slno', '=', $id)->first();
   // return view('book.show',compact('book'));

        $rentData = DB::table('rent')->get();

        $singlData1 = Rent::select('picture')->distinct()->get();

        $user = Rent::select('city')->distinct()->get();
        $bed = Rent::select('bedrooms')->distinct()->get();
        $bath = Rent::select('bathrooms')->distinct()->get();
        $cat = category::select('id','name')->distinct()->get();
 $CommentsData = DB::table('comments')->get();
 $footerslide1 = DB::table('carausel')->distinct()->get();


        //$user2 = comment::select('picture')->distinct()->get();
        return view('Project.index')
                ->with(compact('user'))
                ->with(compact('cat'))
                ->with(compact('bed'))
                ->with(compact('bath'))
                ->with(compact('singlData1'))
                ->with(compact('rentData'))
                ->with(compact('CommentsData'))
                ->with(compact('footerslide1'));
       

    

    }
}
