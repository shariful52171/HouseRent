<?php

namespace App\Http\Controllers;
use App\Category;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Request;
use App\contactus;
//use Illuminate\Http\Request;

class ContactusController extends Controller
{
    
    public function index()
    {
        $Contactus=contactus::all();
      //return 'heello0';
         $Contactus= DB::table('contactuses')->paginate(2);

       return view('Contactus.index')->with('Contactus',$Contactus);
    }

    
    public function create()
    {
        return view('Contactus.create');
    }

    
    public function store()
    {
        $Contactus=Request::all();
   contactus::create($Contactus);
   return redirect('Contactus');
    }

    
    public function show($id)
    {
         $Contactus=contactus::where('id', '=', $id)->first();
         //return $Contactus;
   return view('Contactus.show',compact('Contactus'));

    }

    
    public function edit($id)
    {
         $Contactus=contactus::find($id);
        return view('Contactus.edit',compact('Contactus'));
    }

    
    public function update($id)
{
      $ContactusUpdate=Request::all();
   $Contactus=contactus::find($id);
   $Contactus->update($ContactusUpdate);
   return redirect('contactus');
}

    
    public function destroy($id)
    {
         contactus::find($id)->delete();
   return redirect('contactus');
    }
}
