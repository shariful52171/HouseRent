<?php

namespace App\Http\Controllers;
use App\Comment;
use App\contactus;
use App\Aboutus;
use DB;
use Illuminate\Http\Request;

class ViewController extends Controller
{
   public function Comment()
    {
        $Comments=Comment::all();
         //$Proposes = DB::table('Proposes')->paginate(2);

       return view('ShowPages.comment')->with('Comments',$Comments);
    }

    //  public function createcomment()
    // {
    //     return view('ShowPages.createcomment');
    // }
    
     public function createcomment()
    {
        return view('ShowPages.createcomment');
    }
    
     public function createcontactus()
    {
        //$Contactus=contactus::all();
 $footerslide1 = DB::table('carausel')->distinct()->get();

        

                
        return view('ShowPages.createcontact')->with(compact('footerslide1'));
    }

 //    public function store(Request $request)
 //    {

 //        $Service=Request::all();

 //   contactus::create($Service);
 //   return "Successfully sent";
 //    }
  //   public function store(Request $request)
  //   {
  //       //return "you are fired";
  // $mdatas=Request::all();
  //  contactus::create($mdatas);
    public function create()
    {
 $footerslide1 = DB::table('carausel')->distinct()->get();

        $Comments=contactus::all();
         //$Proposes = DB::table('Proposes')->paginate(2);

       return view('Project.contact')->with('contactus',$Comments)->with(compact('footerslide1'));
    }


public function store(Request $rquest){

        $mdatas=Request::all();
        return $mdatas;
        contactus::create($mdatas);
        return view('Project.success');
}
    

   
}
