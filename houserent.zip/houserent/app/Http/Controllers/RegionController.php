<?php
namespace App\Http\Controllers;
use App\Rent;

use Illuminate\Http\Request;
use DB;

class RegionController extends Controller
{
  
   
 public function Regiondetails($id){
       
$footerslide1 = DB::table('carausel')->distinct()->get();
       // $regiondetails=Rent::where('city', '=', $id)->get();
        //$regiondetails=DB::table('Rent')->get();
        $regiondetails = Rent::select('id','city','category','description','floor','bathrooms','bedrooms','area','liftfacility','picture','face')->where('city', 'like', '%'.$id. '%')->get();
        //echo $singlData1;


      //echo $regiondetails;
       return view('Region.regiondetails')->with(compact('regiondetails'))->with(compact('footerslide1'));
    }


}