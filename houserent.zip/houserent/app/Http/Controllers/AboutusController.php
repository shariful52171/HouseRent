<?php

namespace App\Http\Controllers;

use App\Aboutus;

use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Request;
use App\contactus;

class AboutusController extends Controller
{
   public function index()
    {
        $Aboutus=Aboutus::all();
      //return 'heello0';
         $Aboutus= DB::table('Aboutuses')->paginate(2);

       return view('Aboutus.index')->with('Aboutus',$Aboutus);
    }

    
    public function create()
    {
        return view('Aboutus.create');
    }

    
    public function store()
    {
        $Aboutus=Request::all();
   Aboutus::create($Aboutus
);
   return redirect('Aboutus');
    }

    
    public function show($id)
    {
         $Aboutus=Aboutus::where('id', '=', $id)->first();
         //return $Aboutus;
   return view('Aboutus.show',compact('Aboutus'));

    }

    
    public function edit($id)
    {
         $Aboutus=Aboutus::find($id);
        return view('Aboutus.edit',compact('Aboutus'));
    }

    
    public function update($id)
{
      $AboutusUpdate=Request::all();
   $Aboutus=Aboutus::find($id);
   $Aboutus->update($AboutusUpdate);
   return redirect('Aboutus');
}

    
    public function destroy($id)
    {
         Aboutus::find($id)->delete();
   return redirect('Aboutus');
    }
}

