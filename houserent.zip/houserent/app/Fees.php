<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fees extends Model
{
    public $primaryKey  = 'voucherno';
	 protected $fillable=[
        'id',
        'date',
        'amount'
    ];

public function Students()
{
return $this->belongsTo('App\Students');
}
}