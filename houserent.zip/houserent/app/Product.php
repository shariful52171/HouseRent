<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'title',
        'heading',
        'category',
        'description',
        'picture'
    ];
}
