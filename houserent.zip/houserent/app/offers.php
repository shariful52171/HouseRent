<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class offers extends Model
{
    public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'rent_id',
        'offer_percent'
    ];
}
