<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    public $table="comments";
	 public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'name',
        'email',
        'title',
        'comment',
        'active',
        'picture'
    ];
}
