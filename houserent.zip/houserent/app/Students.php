<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Students extends Model
{
   public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'name',
        'class'
    ];
public function Fees()
{
return $this->hasMany('App\Fees','id','id');
}
}

