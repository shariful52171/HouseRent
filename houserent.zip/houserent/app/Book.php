<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
 public $primaryKey  = 'slno';
	 protected $fillable=[
        'slno',
        'isbn',
        'name'
    ];
}
