<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contactus extends Model
{
    public $table="contactuses";
     public $primaryKey  = 'id';
	 protected $fillable=[
        'id',
        'name',
        'email',
        'category',
        'description'

];
}
