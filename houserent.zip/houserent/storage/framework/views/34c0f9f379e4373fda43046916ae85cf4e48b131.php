<?php $__env->startSection('content'); ?>
    <h1>Create Products</h1>
    <?php echo Form::open(['url' => 'Products']); ?>

	  <div class="form-group">
        <?php echo Form::label('id', 'id:'); ?>

        <?php echo Form::text('id',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('title', 'title:'); ?>

        <?php echo Form::text('title',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('heading', 'heading:'); ?>

        <?php echo Form::text('heading',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('category', 'category:'); ?>

        <?php echo Form::text('category',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('description', 'description:'); ?>

        <?php echo Form::text('description',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('picture', 'picture:'); ?>

        <?php echo Form::text('picture',null,['class'=>'form-control']); ?>

    </div>
  <div class="form-group">
        <?php echo Form::submit('Save', ['class' => 'btn btn-primary form-control']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts/dashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>