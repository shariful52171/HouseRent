<?php $__env->startSection('content'); ?>
 <h1>Total Rent store</h1>
 <a href="<?php echo e(url('/Rent/create')); ?>" class="btn btn-success">Create Rent</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>City</th>
         <th>Category</th>
         <th>Bedrooms</th>
         <th>Bathrooms</th>
         <th>Area</th>
         <th>Face</th>
         <th>Floor</th>
         <th>Lift Facility</th>
         <th>Description</th>
         <th>Picture</th>
      
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Rent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->city); ?></td>
             <td><?php echo e($Student->category); ?></td>
             <td><?php echo e($Student->bedrooms); ?></td>
             <td><?php echo e($Student->bathrooms); ?></td>
             <td><?php echo e($Student->area); ?></td>
             <td><?php echo e($Student->face); ?></td>
             <td><?php echo e($Student->floor); ?></td>
             <td><?php echo e($Student->liftfacility); ?></td>
             <td><?php echo e($Student->description); ?></td>
           


             <?php
             if( !file_exists( base_path()."\\public\\images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/<?php echo e($Student->picture); ?>' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
			 <td><a href="<?php echo e(url('Rent',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
           

             <td><a href="<?php echo e(route('Rent.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td>
            

              <td><a href="<?php echo e(route('RentUpload.edit',$Student->id)); ?>" class="btn btn-info">Upload</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE',
       'route'=>['Rent.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
</div>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts/dashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>