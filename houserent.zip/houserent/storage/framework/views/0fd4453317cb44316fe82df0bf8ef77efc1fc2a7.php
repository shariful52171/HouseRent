<?php $__env->startSection('content'); ?>
<h1>Update Student</h1>
<?php echo Form::model($student,['method'=>'PATCH','route'=>['RentUpload.update',$student->id],'files'=>true]); ?>



<div class="form-group">
        <?php echo Form::label('id', 'id:'); ?>

        <?php echo Form::text('id',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('city', 'city:'); ?>

        <?php echo Form::text('city',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('category', 'category:'); ?>

        <?php echo Form::text('category',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('bedrooms', 'bedrooms:'); ?>

        <?php echo Form::text('bedrooms',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('bathrooms', 'bathrooms:'); ?>

        <?php echo Form::text('bathrooms',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('area', 'area:'); ?>

        <?php echo Form::text('area',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('face', 'face:'); ?>

        <?php echo Form::text('face',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('floor', 'floor:'); ?>

        <?php echo Form::text('floor',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('liftfacility', 'liftfacility:'); ?>

        <?php echo Form::text('liftfacility',null,['class'=>'form-control']); ?>

    </div>
     <div class="form-group">
        <?php echo Form::label('description', 'description:'); ?>

        <?php echo Form::text('description',null,['class'=>'form-control']); ?>

    </div> <div class="form-group">
        <?php echo Form::label('picture', 'picture:'); ?>

        <?php echo Form::file('picture',null,['class'=>'form-control']); ?>

    </div>

<div class="form-group">
	
	<?php echo Form::submit('Upload',['class'=>'btn btn-primary']); ?>

</div>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>