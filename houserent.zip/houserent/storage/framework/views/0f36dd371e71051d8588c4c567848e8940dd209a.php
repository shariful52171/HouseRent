<?php $__env->startSection('content'); ?>
    <h1>Update Students</h1>
    <?php echo Form::model($Students,['method' => 'PATCH','route'=>['Students.update',$Students->id]]); ?>

	<div class="form-group">
        <?php echo Form::label('id', 'id:'); ?>

        <?php echo Form::text('id',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('name', 'name:'); ?>

        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('class', 'class:'); ?>

        <?php echo Form::text('class',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>