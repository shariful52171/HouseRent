<?php $__env->startSection('content'); ?>
 <h1>Total Contactus
 store</h1>
 <a href="<?php echo e(url('/contactus/create')); ?>" class="btn btn-success">Create Contactus</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Name</th>
         <th>Email</th>
         <th>Category</th>
         <th>Description</th>
       
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Contactus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->name); ?></td>
             <td><?php echo e($Student->email); ?></td>
             <td><?php echo e($Student->category); ?></td>
             <td><?php echo e($Student->description); ?></td>
            
       <td><a href="<?php echo e(url('contactus',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
             <td><a href="<?php echo e(route('contactus.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE',
       'route'=>['contactus.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($Contactus->links()); ?>

  </tbody>
 </table>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard_layouts/dashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>