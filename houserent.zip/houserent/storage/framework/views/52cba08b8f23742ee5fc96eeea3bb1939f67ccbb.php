<?php $__env->startSection('content'); ?>
 <h1>Students List</h1>
 <a href="<?php echo e(url('/Students/create')); ?>" class="btn btn-success">Create Student</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>ID</th>
         <th>Students Name</th>
         <th>Class</th>
         <th>Picture</th>
         <th colspan="4">Actions</th>
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($student->id); ?></td>
             <td><?php echo e($student->name); ?></td>
             <td><?php echo e($student->class); ?></td>
             <?php
             if( !file_exists( base_path()."\\public\\images\\".$student->picture) || $student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/<?php echo e($student->picture); ?>' class="img-responsive" width="100px"/></td>
             <?php } ?>
			 <td><a href="<?php echo e(url('Students',$student->id)); ?>" class="btn btn-primary">Read</a></td>
        <td><a href="<?php echo e(route('StUpload.edit',$student->id)); ?>" class="btn btn-info">Upload</a></td>
        <td><a href="<?php echo e(route('Students.edit',$student->id)); ?>" class="btn btn-warning">Update</a></td>
             <td>
            <?php echo Form::open(['method' => 'DELETE', 'route' => ['Students.destroy', $student->id]]); ?>

                <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>