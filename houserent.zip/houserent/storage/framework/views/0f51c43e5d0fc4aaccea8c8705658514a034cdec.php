<?php $__env->startSection('content'); ?>
 <h1>Peru booktore</h1>
 <a href="<?php echo e(url('/book/create')); ?>" class="btn btn-success">Create Book</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>Slno</th>
         <th>ISBN Number</th>
         <th>Book Name</th>
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($book->slno); ?></td>
             <td><?php echo e($book->isbn); ?></td>
             <td><?php echo e($book->name); ?></td>
			 <td><a href="<?php echo e(url('book',$book->slno)); ?>" class="btn btn-primary">Read</a></td>
             <td><a href="<?php echo e(route('book.edit',$book->slno)); ?>" class="btn btn-warning">Update</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE',
       'route'=>['book.destroy',$book->slno]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   
	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>