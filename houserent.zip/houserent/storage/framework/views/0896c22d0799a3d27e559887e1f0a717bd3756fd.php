<?php $__env->startSection('content'); ?>
<h1>Search Students</h1>
<?php echo Form::open(['url'=>'st/searchfeebyname','method'=>'get']); ?>

<?php echo Form::select('q', $stidnames,null, array('class' => 'form-control')); ?>

<button type="submit">Search</button>
</form>
<?php $__currentLoopData = $Fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table class="table">
<tr>
<td>
ID: <?php echo e($fee->id); ?>

</td>
<td>
Name:  <a href="<?php echo e(URL::route('Students.show', ['id' => $fee->id])); ?>"><?php echo e($fee->name); ?></a>
</td>
<td>
Class: <?php echo e($fee->class); ?>

</td>
<td>
Voucher No: <a href="<?php echo e(URL::route('Fees.show', ['id' => $fee->voucherno])); ?>"><?php echo e($fee->voucherno); ?></a>
</td>
<td>
Amount: <?php echo e($fee->amount); ?>

</td>
<td>
Date: <?php echo e($fee->date); ?>

</td>
</tr>
</table>              
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>