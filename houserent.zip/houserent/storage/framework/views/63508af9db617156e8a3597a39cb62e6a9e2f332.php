<?php $__env->startSection('content'); ?>
    <h1>Create Contactus
</h1>
    <?php echo Form::open(['url' => 'store']); ?>

	  <div class="form-group">
        <?php echo Form::label('id', 'id:'); ?>

        <?php echo Form::text('id',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('name', 'name:'); ?>

        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('email', 'email:'); ?>

        <?php echo Form::text('email',null,['class'=>'form-control']); ?>

    </div>
     <div class="form-group">
        <?php echo Form::label('category', 'category:'); ?>

        <?php echo Form::text('category',null,['class'=>'form-control']); ?>

    </div>
     <div class="form-group">
        <?php echo Form::label('description', 'description:'); ?>

        <?php echo Form::text('description',null,['class'=>'form-control']); ?>

    </div>
   
  <div class="form-group">
        <?php echo Form::submit('Send', ['class' => 'btn btn-primary form-control']); ?>

    </div>
    
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Project_layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>