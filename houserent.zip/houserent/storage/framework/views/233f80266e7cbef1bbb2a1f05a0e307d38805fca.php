<?php $__env->startSection('content'); ?>
<h1>Update Student</h1>
<?php echo Form::model($student,['method'=>'PATCH','route'=>['CommentsUpload.update',$student->id],'files'=>true]); ?>


 <div class="form-group">
        <?php echo Form::label('id', 'id:'); ?>

        <?php echo Form::text('id',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('name', 'name:'); ?>

        <?php echo Form::text('name',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('email', 'email:'); ?>

        <?php echo Form::text('email',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('title', 'title:'); ?>

        <?php echo Form::text('title',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('comment', 'comment:'); ?>

        <?php echo Form::text('comment',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('active', 'active:'); ?>

        <?php echo Form::text('active',null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('picture', 'picture:'); ?>

        <?php echo Form::file('picture',null,['class'=>'form-control']); ?>

    </div>

<div class="form-group">
	
	<?php echo Form::submit('Upload',['class'=>'btn btn-primary']); ?>

</div>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>