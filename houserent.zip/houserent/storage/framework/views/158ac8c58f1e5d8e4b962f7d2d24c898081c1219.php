<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo URL::to('/'); ?>/bootstrap.css">


<!-- start of main area -->
    <div class="content">
        <div class="wrap">
          <div class="wrapper">
           
<div class=""> 
  <div style="float: left;">  
<?php $__currentLoopData = $regiondetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regiondetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4"> 
            <div class="con-bot">

              <hr/>

           
<!-- Pic Upload -->

            <?php
             if( !file_exists( base_path()."\\public\\images\\".$regiondetails->picture) || $regiondetails->picture=='') { ?>
            <div>
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="50px"/>
            </div>
            <?php } else { ?>
            <div>
                <img style="border-radius: 30px" src="<?php echo e(URL::to('public/images/'.$regiondetails->picture)); ?>" width="300px" height="200px"/>
            </div>
            <?php } ?>
<!-- /Pic Upload -->

          
            
            <div style="font-family: verdana; font-size: 17px">
              <br><b>ID:</b> <?php echo e($regiondetails->id); ?>

              <br><b>City:</b> <?php echo e($regiondetails->city); ?>

              <br><b>Category:</b> <?php echo e($regiondetails->category); ?>

              <br><b>Bedroom:</b> <?php echo e($regiondetails->bedrooms); ?>

              <br><b>Bathrooms:</b> <?php echo e($regiondetails->bathrooms); ?>

              <br><b>Area:</b> <?php echo e($regiondetails->area); ?>

              <br><b>Face:</b> <?php echo e($regiondetails->face); ?>

              <br><b>Floor:</b> <?php echo e($regiondetails->floor); ?>

              <br><b>Lift Facility:</b> <?php echo e($regiondetails->liftfacility); ?>

              <br><b>Description:</b> <?php echo e($regiondetails->description); ?>

              <br><b>Picture:</b> <?php echo e($regiondetails->picture); ?>


            </div>              <hr/>
            

            </div>
              <div class="clear"></div>
      </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
        </div>
    </div>
    
</div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Project_layouts/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>