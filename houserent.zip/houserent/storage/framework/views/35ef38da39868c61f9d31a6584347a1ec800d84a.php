<?php $__env->startSection('content'); ?>
 <h1>Total Carausel store</h1>
 <a href="<?php echo e(url('/Carausel/create')); ?>" class="btn btn-success">Create Carausel</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>title</th>
         <th>category</th>
         <th>location</th>
         <th>picture</th>
         
         
       
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Carausel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->title); ?></td>
             <td><?php echo e($Student->category); ?></td>
             <td><?php echo e($Student->location); ?></td>
             <td><?php echo e($Student->picture); ?></td>
             
             <?php
             if( !file_exists( base_path()."\\public\\carausel_images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\carausel_images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/carausel_images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\carausel_images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/carausel_images/<?php echo e($Student->picture); ?>' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
            
             <td><a href="<?php echo e(url('Carausel',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
			 <td><a href="<?php echo e(url('Carausel',$Student->id)); ?>" class="btn btn-primary">Update</a></td>
             <!-- <td><a href="<?php echo e(route('Carausel.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td> -->
              <td><a href="<?php echo e(route('Carausel.edit',$Student->id)); ?>" class="btn btn-info">Upload image</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE','route'=>['Carausel.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>



       

          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>