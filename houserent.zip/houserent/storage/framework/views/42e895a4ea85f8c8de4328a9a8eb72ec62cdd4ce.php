<?php $__env->startSection('content'); ?>
<h1>Search Students</h1>
<?php echo Form::open(['url'=>'st/search','method'=>'get']); ?>

<input type="text"  name="q" placeholder="Search.."/>
<button type="submit">Search</button>
</form>
<?php $__currentLoopData = $Students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table class="table">
<tr>
<td>
ID: <?php echo e($student->id); ?>

</td>
<td>
Name: <a href="<?php echo e(URL::route('Students.show', ['id' => $student->id])); ?>"><?php echo e($student->name); ?></a>
</td>
<td>
Class: <?php echo e($student->class); ?><br/>
</td>
</tr>
</table>              
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>