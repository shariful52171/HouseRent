<?php $__env->startSection('content'); ?>
 <h1>Total Category store</h1>
 <a href="<?php echo e(url('/Category/create')); ?>" class="btn btn-success">Create Category</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Name</th>
       
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->name); ?></td>
            
			 <td><a href="<?php echo e(url('Category',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
             <td><a href="<?php echo e(route('Category.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE',
       'route'=>['Category.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($Category->links()); ?>

	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>