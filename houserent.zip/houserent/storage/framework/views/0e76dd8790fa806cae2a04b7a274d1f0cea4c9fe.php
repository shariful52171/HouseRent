<?php $__env->startSection('content'); ?>
    <h1>Aboutus Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">ID</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder=<?php echo e($Aboutus->id); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Aboutus->title); ?> readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="<?php echo e(url('Aboutus')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts/dashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>