<?php $__env->startSection('content'); ?>
    <h1>Products Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">ID</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder=<?php echo e($Products->id); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Title</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Products->title); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Products->heading); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Category</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Products->category); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Description</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Products->description); ?> readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Picture</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder=<?php echo e($Products->picture); ?> readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="<?php echo e(url('Products')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>