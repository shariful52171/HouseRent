<?php $__env->startSection('content'); ?>
 <h1>Total Comments
 store</h1>
 <a href="<?php echo e(url('/Comments/create')); ?>" class="btn btn-success">Create Comments
</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>name</th>
         <th>email</th>
         <th>title</th>
         <th>comment</th>
         <th>active</th>
         <th>picture</th>
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->name); ?></td>
             <td><?php echo e($Student->email); ?></td>
             <td><?php echo e($Student->title); ?></td>
             <td><?php echo e($Student->comment); ?></td>
             <td><?php echo e($Student->active); ?></td>
             <td><?php echo e($Student->picture); ?></td>


             <?php
             if( !file_exists( base_path()."\\public\\images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/<?php echo e($Student->picture); ?>' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
			 <td><a href="<?php echo e(url('Comments',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
             <td><a href="<?php echo e(route('Comments.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td>

              <td><a href="<?php echo e(route('CommentsUpload.edit',$Student->id)); ?>" class="btn btn-info">Upload</a></td>
            <td>

       <?php echo Form::open(['method'=>'DELETE','route'=>['Comments.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
	</tbody>
 </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>