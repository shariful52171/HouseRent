<?php $__env->startSection('content'); ?>
 <h1>Total Aboutus

 store</h1>
 <a href="<?php echo e(url('Aboutus/create')); ?>" class="btn btn-success">Create Aboutus
</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Title</th>
         
         <th>Description</th>
       
   </tr>
     </thead>
     <tbody>
     <?php $__currentLoopData = $Aboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <td><?php echo e($Student->id); ?></td>
             <td><?php echo e($Student->title); ?></td>
            
             <td><?php echo e($Student->description); ?></td>
            
       <td><a href="<?php echo e(url('Aboutus',$Student->id)); ?>" class="btn btn-primary">Read</a></td>
             <td><a href="<?php echo e(route('Aboutus.edit',$Student->id)); ?>" class="btn btn-warning">Update</a></td>
            <td>
       <?php echo Form::open(['method'=>'DELETE',
       'route'=>['Aboutus.destroy',$Student->id]]); ?>


         <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>


          <?php echo Form::close(); ?>

    </td>
         </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($Aboutus->links()); ?>

  </tbody>
 </table>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard_layouts/dashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>