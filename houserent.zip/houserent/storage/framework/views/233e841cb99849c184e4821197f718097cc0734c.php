<?php $__env->startSection('content'); ?>

<!-- start of main area -->
    <div class="content">
        <div class="wrap">
          <div class="wrapper">
           
            <div class="con-bot">

              <hr/>

              <div class="clear"></div>
              <div>

<!-- Pic Upload -->
            <?php
             if( !file_exists( base_path()."\\public\\images\\".$showdetails->picture) || $showdetails->picture=='') { ?>
            <td>
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="100px"/>
            </td>
            <?php } else { ?>
            <td>
                <img style="border-radius: 50px" src="<?php echo e(URL::to('public/images/'.$showdetails->picture)); ?>" />
            </td>
            <?php } ?>
<!-- /Pic Upload -->

              </div>
            
            <div style="font-family: verdana; font-size: 17px">
              <br><br><b>ID:</b> <?php echo e($showdetails->id); ?>

              <br><br><b>City:</b> <?php echo e($showdetails->city); ?>

              <br><br><b>Category:</b> <?php echo e($showdetails->category); ?>

              <br><br><b>Bedroom:</b> <?php echo e($showdetails->bedrooms); ?>

              <br><br><b>Bathrooms:</b> <?php echo e($showdetails->bathrooms); ?>

              <br><br><b>Area:</b> <?php echo e($showdetails->area); ?>

              <br><br><b>Face:</b> <?php echo e($showdetails->face); ?>

              <br><br><b>Floor:</b> <?php echo e($showdetails->floor); ?>

              <br><br><b>Lift Facility:</b> <?php echo e($showdetails->liftfacility); ?>

              <br><br><b>Description:</b> <?php echo e($showdetails->description); ?>

              <br><br><b>Picture:</b> <?php echo e($showdetails->picture); ?>


            </div>              <hr/>
            

            </div>
          </div>
        </div>
    </div>
     <div >
                <p style="text-align: center;"> <a  href="<?php echo e(url('/send/create')); ?>">Propose</a></p>
               </div>
<!-- end of main area -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Project_layouts/template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>