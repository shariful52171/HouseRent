 <?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\User;
use Illuminate\Support\Facades\Input;
 
Route::get ( '/', function () {
    return view ( 'welcome' );
} );
Route::post ( '/search', function () {

    $q = Input::get ( 'q' );
    $user = User::where ( 'name', 'LIKE', '%' . $q . '%' )->orWhere ( 'email', 'LIKE', '%' . $q . '%' )->get ();
    if (count ( $user ) > 0)
        return view ( 'welcome' )->withDetails ( $user )->withQuery ( $q );
    else
        return view ( 'welcome' )->withMessage ( 'No Details found. Try to search again !' );
} );



use App\Rent;
use App\category;
//use Illuminate\Support\Facades\Input;

 
Route::get ( '/', function () {
    return view ( 'Project.index' );
} );
Route::post ( '/search', function () {
        $singlData1 = Rent::select('picture')->distinct()->get();
    	$user = Rent::select('city')->distinct()->get();
    	$cat = category::select('id','name')->distinct()->get();
    	$bed = Rent::select('bedrooms')->distinct()->get();
    	$bath = Rent::select('bathrooms')->distinct()->get();
    	$rentData = DB::table('rent')->get();
 $CommentsData = DB::table('comments')->get();
    	
 $footerslide1 = DB::table('carausel')->distinct()->get();






	
    $q = Input::get ( 'q' );
    $user = Rent::where ( 'id', 'LIKE', '%' . $q . '%' )->orWhere ( 'city', 'LIKE', '%' . $q . '%' )->get ();
    if (count ( $user ) > 0)
        return view ( 'Project.index' )->withDetails ( $user )->withQuery ( $q )->with(compact('singlData1'))->with(compact('user'))->with(compact('cat'))->with(compact('bed'))->with(compact('bath'))->with(compact('rentData'))->with(compact('CommentsData'))->with(compact('footerslide1'));
    else
        return view ( 'Project.index' )->withMessage ( 'No Details found. Try to search again !' )->with(compact('singlData1'))->with(compact('user'))->with(compact('cat'))->with(compact('bed'))->with(compact('bath'))->with(compact('rentData'))->with(compact('CommentsData'))->with(compact('footerslide1'));
} );

Route::get('/', function () {
    return view('welcome');
    
});
//Route::resource('/Project');
   Route::get('/','ProjectController@index');

// Route::get('Book','BookController@index');
// Route::get('/edit',['as'=>'book.edit','uses'=>'BookController@edit']);
Route::resource('book','BookController');
Route::resource('Students','StudentsController');
Route::resource('Fees','FeesController');
Route::resource('Products','ProductsController');
Route::get('st/search',['uses'=>'StudentsController@getSearch','as'=>'search']);
Route::get('st/searchfee',['uses'=>'StudentsController@getSearchfee','as'=>'searchfee']);
Route::get('st/searchfeebyname',['uses'=>'StudentsController@getSearchfeebyname','as'=>'searchfeebyname']);
Route::get('pt/searchfeebyname',['uses'=>'ProjectController@getSearchfeebyname','as'=>'searchfeebyname']);
Route::get('st/showcon/{city}/{cat}',['uses'=>'StudentsController@showcon','as'=>'showcon']);


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/Students', 'StudentsController@index')->name('Students');
Auth::routes();

Route::get('admin/Products', 'ProductsController@index')->name('Products');
Auth::routes();

Route::get('/Fees', 'FeesController@index')->name('Fees');
Auth::routes();

Route::get('/book', 'bookController@index')->name('book');
Route::resource('Offers','OffersController');
Route::resource('admin/Category','CategoryController');
Route::resource('admin/Rent','RentController');
Route:: Resource ('StUpload','StUploadController');
Route:: Resource ('admin/RentUpload','RentUploadController');
Route:: Resource ('admin/Carausel','CarauselController');




Route:: get('/Project','ProjectController@index');
Route:: resource('admin/Comments','CommentsController');
Route:: Resource ('admin/CommentsUpload','CommentsUploadController');
Route::get('/showdetails/{id}', 'ProjectController@showdetails');
// Route::resource('propose', 'ProjectController');
Route::resource('send', 'ProjectController');
Route::resource('Proposes', 'ProposesController');
Route:: get('/Comment','ViewController@Comment');
Route:: get('createcontactus','ViewController@createcontactus');
//Route:: get('store','ViewController@store');
Route::get('/regiondetails/{id}', 'RegionController@regiondetails');
Route:: resource('admin/contactus','ContactusController');
Route:: resource('admin/Aboutus','AboutusController');
Route:: resource('service','ServicesController');


Route:: get('contact','MessageController@create');
Route:: resource('contactSave','MessageController');

Route:: get('About','MessageController@About');






Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//admin routes.............
    Route::get('admin/home', 'AdminController@index');

        $this->get('admin', 'admin\LoginController@showLoginForm')->name('admin.login');
        $this->post('admin', 'admin\LoginController@login');
        $this->post('logout', 'Auth\LoginController@logout')->name('logout');

       
        // Password Reset Routes...
        $this->get('admin.password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
        // $this->post('admin.password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
        // $this->get('admin.password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
        // $this->post('admin.password/reset', 'Auth\ResetPasswordController@reset');









//Route:: get('/showcon/{$id}','ProjectController@getSearchfeebyname');

