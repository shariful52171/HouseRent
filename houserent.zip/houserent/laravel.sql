-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2018 at 10:37 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutuses`
--

CREATE TABLE `aboutuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `aboutuses`
--

INSERT INTO `aboutuses` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(2, 'dfhghg', 'hfdffhdfh', '2018-07-22 22:09:48', '2018-07-22 22:09:48'),
(10, 'gjjkll', 'Integer nec bibendum lacus. Suspendisse dictum enim sit ame', '2018-07-25 12:31:57', '2018-07-25 12:31:57'),
(11, 'fjhfjhgf', '<p>                         <img data-wow-delay=\"350ms\" src=\"http://localhost:8080/laravel-5.5_sharif_all_25_07_2018_Project_new/public/img/bg-img/about.jpg\" alt=\"\" class=\"fr-image-dropped fr-fin fr-dii\" title=\"\">                           </p><p data-wow-delay=\"450ms\">Integer  nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.  Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero  malesuada feugiat. Praesent malesuada congue magna at finibus. In hac  habitasse platea dictumst. Curabitur rhoncus auctor eleifend. Fusce  venenatis diam urna, eu pharetra arcu varius ac. Etiam cursus turpis  lectus, id iaculis risus tempor id. Phasellus fringilla nisl sed sem  scelerisque, eget aliquam magna vehicula.</p><p>                     </p>', '2018-07-25 13:02:06', '2018-07-25 13:02:06');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$E30kUj3aW/mh7Mx4t3.Ni.4nihIyWEugLa8D6X5wkHJt5izgC8vlO', 'MWCMn5oXUOCANUtrmeP3YswahKs22KXXyhnbP7nkcgkar4F9B3bXORVYdS2N', '2018-07-28 18:00:00', '2018-07-28 18:00:00'),
(2, 'kk', 'kkk@gmail.com', '123456', '123456', '2018-07-28 18:00:00', '2018-07-28 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `slno` int(11) NOT NULL,
  `isbn` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`slno`, `isbn`, `name`, `updated_at`, `created_at`) VALUES
(12, 7777, 'dsgssgd', '2018-06-23 06:11:06', '2018-06-12 00:00:00'),
(124, 9999, 'dfsds', '2018-06-23 06:11:14', '2018-06-23 06:10:04'),
(123454, 5445656, ';;dfs\';dfs;lklds;', '2018-06-23 07:02:31', '2018-06-23 07:02:31');

-- --------------------------------------------------------

--
-- Table structure for table `carausel`
--

CREATE TABLE `carausel` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carausel`
--

INSERT INTO `carausel` (`id`, `title`, `category`, `location`, `picture`, `created_at`, `updated_at`) VALUES
(1, 'New Title11', 'Double', 'sassfad', 'download1.png', '2018-07-07 01:14:20', '2018-07-15 21:39:07'),
(2, 'Stylist Bag', 'Double', 'sassfad', 'feature8.jpg', '2018-07-16 01:18:00', '2018-07-16 01:28:10'),
(3, 'New House', 'single', 'chittagong', 'feature7.jpg', '2018-07-16 01:56:24', '2018-07-16 01:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'single', '2018-07-03 00:05:13', '2018-07-03 00:05:13'),
(2, 'duplex room', '2018-07-03 00:05:29', '2018-07-03 00:05:29'),
(4, 'Apartment', '2018-07-04 21:27:28', '2018-07-04 21:27:28'),
(5, 'Bar', '2018-07-04 21:27:49', '2018-07-04 21:27:49'),
(6, 'Farm', '2018-07-04 21:28:07', '2018-07-04 21:28:07'),
(7, 'House', '2018-07-04 21:28:23', '2018-07-04 21:28:23'),
(8, 'Store', '2018-07-04 21:28:41', '2018-07-04 21:28:41'),
(9, 'Drancing', '2018-07-04 21:28:57', '2018-07-04 21:28:57');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `email`, `title`, `comment`, `picture`, `active`, `created_at`, `updated_at`) VALUES
(3, 'single1', 'shariful.sharif52171@gmail.com', 'New Title11', 'dgssdg b  gds', 'download2.png', 1, '2018-07-15 22:10:02', '2018-07-15 23:09:16'),
(4, 'mahdi', 'arif@gmail.com', 'Wonderful', 'Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit amet tellus blandit. Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit am et tellus blandit. Etiam nec odio vestibul. Etiam nec odio vestibulum est mat tis effic iturut magna.', 'hero1.jpg', 1, '2018-07-16 00:29:22', '2018-07-16 00:29:55'),
(5, 'sharif', 'arif@yahoo.com', 'Beautiful', 'Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit amet tellus blandit. Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit am et tellus blandit. Etiam nec odio vestibul. Etiam nec odio vestibulum est mat tis effic iturut magna.', 'feature3.jpg', 1, '2018-07-16 00:31:12', '2018-07-16 00:31:33'),
(6, 'Shariful Islam', 'shariful.sharif52171@gmail.com', 'New Style', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod             tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,             quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo             consequat.', 'feature8.jpg', 1, '2018-07-16 00:34:16', '2018-07-16 00:34:34');

-- --------------------------------------------------------

--
-- Table structure for table `contactuses`
--

CREATE TABLE `contactuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contactuses`
--

INSERT INTO `contactuses` (`id`, `name`, `email`, `category`, `description`, `created_at`, `updated_at`) VALUES
(1, 'fff', 'ffff', 'ffff', 'fffff', '2018-07-29 18:00:00', '2018-07-29 18:00:00'),
(2, 'shariful;\'', 'sariful@gmail.c\'\'\'om', '\';\'\';lkgf', 'Awesome room', '2018-07-30 02:10:23', '2018-07-30 02:10:23');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `voucherno` int(10) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`voucherno`, `id`, `date`, `amount`, `created_at`, `updated_at`) VALUES
(2, 6, '2018-06-24', 13000, '2018-06-25 00:48:24', '2018-06-25 00:48:24'),
(3, 7, '2018-06-24', 122252, '2018-06-27 02:13:21', '2018-06-30 00:37:05'),
(4, 5, '2018-06-24', 50000, '2018-06-27 02:13:41', '2018-06-27 02:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_06_24_072250_create_table_todolists_2018_06_24', 1),
(2, '2018_06_24_073333_create_table_students_2018_06_24', 2),
(3, '2018_06_25_052607_create_table_fees_2018_06_24', 3),
(4, '2018_06_27_043153_create_table_products_2018_06_27', 4),
(5, '2018_07_01_033333_create_table_rent_2018_07_01', 5),
(6, '2018_07_01_040241_create_table_category_2018_07_01', 6),
(7, '2018_07_01_040719_create_table_offers_2018_07_01', 7),
(8, '2018_07_07_033725_create_table_carausel', 8),
(9, '2018_07_12_063308_create_comments_table', 9),
(10, '2018_07_17_074512_create_proposes_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `newbooks`
--

CREATE TABLE `newbooks` (
  `slno` int(11) NOT NULL,
  `isbn` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newbooks`
--

INSERT INTO `newbooks` (`slno`, `isbn`, `name`, `updated_at`, `created_at`) VALUES
(12, 1223, 'dsgssgd', '2018-06-12 00:00:00', '2018-06-12 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(10) UNSIGNED NOT NULL,
  `rent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offer_percent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `rent_id`, `offer_percent`, `created_at`, `updated_at`) VALUES
(1, '1', '50%', '2018-06-30 22:30:48', '2018-06-30 22:30:48'),
(2, '2', '40%', '2018-06-30 22:30:15', '2018-06-30 22:30:15');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `heading`, `category`, `description`, `picture`, `created_at`, `updated_at`) VALUES
(5, 'Regal Fan', 'Regal 32\" Aircool', 'Fan', 'Air Cooler', 'download.png', NULL, NULL),
(6, 'Mobile', 'Nice', 'Mobile', 'this the wonderful mobile', '2.jpg', NULL, NULL),
(7, 'Mobile', 'offer', 'car', 'this the wonderful mobile', 'index1.jpg', NULL, NULL),
(8, 'car', 'new', 'BMW', 'this the wonderful car', 'index3.jpg', NULL, NULL),
(15, 'sjklsadlk;;l', 'fsda\'df\\\'\\\'gh', 'sdf;l;lglg', 'ssgdgdd', 'dgfg.jpg', '2018-06-26 23:26:48', '2018-06-26 23:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `proposes`
--

CREATE TABLE `proposes` (
  `id` int(10) UNSIGNED NOT NULL,
  `rent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proposes`
--

INSERT INTO `proposes` (`id`, `rent_id`, `name`, `email`, `contact`, `description`, `created_at`, `updated_at`) VALUES
(1, '1', 'klfjdskl', 'arif@gmail.com', 'DSNKFK/LJ', 'This is nice room', '2018-07-17 22:24:10', '2018-07-17 22:24:10'),
(2, '2', 'single1', 'arif@gmail.com', 'DSKLFJSDKL', 'This is nice room', '2018-07-17 22:27:39', '2018-07-17 22:27:39'),
(3, '2', 'single1', 'arif@gmail.com', 'DSKLFJSDKL', 'This is nice room', '2018-07-17 22:28:51', '2018-07-17 22:28:51'),
(4, '3', 'karim', 'k@gmail.com', '123456', 'hello', '2018-07-17 22:35:10', '2018-07-17 22:35:10'),
(5, '1', 'single1', 'arif@gmail.com', 'DSNKFK/LJ', 'hdfhdffh', '2018-07-21 00:52:17', '2018-07-21 00:52:17'),
(6, '5', 'gffd', 'sariful@gmail.com', 'hhfdhf', 'hfdhfdhfhdhfd', '2018-07-24 13:30:37', '2018-07-24 13:30:37');

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `id` int(10) UNSIGNED NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` int(11) NOT NULL,
  `bedrooms` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bathrooms` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `face` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `floor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `liftfacility` tinyint(1) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`id`, `city`, `category`, `bedrooms`, `bathrooms`, `area`, `face`, `floor`, `liftfacility`, `description`, `picture`, `created_at`, `updated_at`) VALUES
(1, 'ctg', 1, '3', '3', 'anderkilla', 'dds kkss', '8', 0, 'This is nice room', 'feature7.jpg', '2018-07-03 00:06:25', '2018-07-15 22:41:01'),
(2, 'dhaka', 2, '2', '2', 'agrabad', 'dddddddddddd', '5', 1, 'nice room', 'hero1.jpg', '2018-07-03 00:08:11', '2018-07-04 22:46:39'),
(3, 'hfg', 1, '1', '1', 'fgfgfg', 'sfds', '8', 0, 'tffd', 'hero4.jpg', '2018-07-04 02:05:22', '2018-07-04 02:13:45'),
(4, 'syhlet', 1, '4', '4', 'Main Town', 'sfdsfsad', '9', 1, 'Wonderful and awsome room', 'hero5.jpg', '2018-07-04 21:22:16', '2018-07-04 21:24:52'),
(5, 'Rajshahi', 5, '2', '3', 'chakbazar', 'nice', '3', 1, 'This is nice Bar', 'feature5.jpg', '2018-07-04 21:40:50', '2018-07-04 21:41:38'),
(6, 'khulna', 6, '6', '4', 'khatowali', 'fsdshgkj gsg', 'Ground', 0, 'This is nice Frarm', 'feature9.jpg', '2018-07-04 21:34:58', '2018-07-04 21:36:22');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(4, 'saaa', 'sssssgg', '2018-07-22 23:00:53', '2018-07-22 23:04:14'),
(5, 'ggggggg', 'gggggggg', '2018-07-22 23:04:33', '2018-07-22 23:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `class`, `picture`, `created_at`, `updated_at`) VALUES
(5, 'mahdi', 'one', 'picture-02.jpg', '2018-06-27 22:22:33', '2018-07-01 00:31:08'),
(6, 'sharif', 'two', '', '2018-06-30 00:35:40', '2018-06-30 00:35:40'),
(7, 'rubel', 'three', '', '2018-06-30 00:36:05', '2018-06-30 00:36:05');

-- --------------------------------------------------------

--
-- Table structure for table `todolists`
--

CREATE TABLE `todolists` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'rif', 'rif@gmail.com', '12345', '12345', '2018-06-29 18:00:00', '2018-06-29 18:00:00'),
(2, 'arif', 'arif@gmail.com', '$2y$10$fzUP/HmFh6weFQeZ51NpHOJTHhCC71wk5KMZA0LMZLZUWqXAnY0FO', 'iTY91xvhJ0tn0blB6RZMro5kvmBHbXVZHMn0ib7bZhDCkGBZps2Ih4UCtfYt', '2018-06-29 21:55:23', '2018-06-29 21:55:23'),
(3, 'a', 'a@aa.aaa', '$2y$10$xMhbKsJJhdXKsSHbWfWS1..rsheNkrchUopRVbDUlrOhgYLLap15S', 'uCcoFekpJ8GRRS51ryksP78oC08ucowa8JahSnppQLYWzyH5Uq7XPGUzGmsY', '2018-06-29 22:15:10', '2018-06-29 22:15:10'),
(4, 'rubel', 'R@gmail.com', '$2y$10$YEGs.Gjp1o9Gig9hxEumX.cXqu.n.6A0Cj8E6GCKwcHi6GQv/mIjS', '1xxo6rd5FJjhxozfG2ElQlBDJ07Um03SDOvGgnMPPc81sfdjn5mCYBPtDRkr', '2018-07-16 00:44:54', '2018-07-16 00:44:54'),
(5, 'ami', 'ami@gmail.com', '$2y$10$E30kUj3aW/mh7Mx4t3.Ni.4nihIyWEugLa8D6X5wkHJt5izgC8vlO', 'MWCMn5oXUOCANUtrmeP3YswahKs22KXXyhnbP7nkcgkar4F9B3bXORVYdS2N', '2018-07-28 13:18:44', '2018-07-28 13:18:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutuses`
--
ALTER TABLE `aboutuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `carausel`
--
ALTER TABLE `carausel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactuses`
--
ALTER TABLE `contactuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`voucherno`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newbooks`
--
ALTER TABLE `newbooks`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proposes`
--
ALTER TABLE `proposes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todolists`
--
ALTER TABLE `todolists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123455;

--
-- AUTO_INCREMENT for table `carausel`
--
ALTER TABLE `carausel`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contactuses`
--
ALTER TABLE `contactuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `voucherno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `newbooks`
--
ALTER TABLE `newbooks`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `proposes`
--
ALTER TABLE `proposes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rent`
--
ALTER TABLE `rent`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `todolists`
--
ALTER TABLE `todolists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rent`
--
ALTER TABLE `rent`
  ADD CONSTRAINT `rent_ibfk_1` FOREIGN KEY (`category`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
