<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableRent20180701 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rent', function (Blueprint $table) {
             $table->increments('id');
             $table->string('city');
             $table->string('category');
             
             $table->string('bedrooms');
             $table->string('bathrooms');
             $table->string('area');
             $table->string('face');
             $table->string('floor');
             $table->boolean('liftfacility');
             $table->string('description');
             $table->string('picture');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('rent');
    }
}
