@extends('layout/template')
@section('content')
 <h1>Total Offers store</h1>
 <a href="{{url('/Offers/create')}}" class="btn btn-success">Create Offers</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>rent_id</th>
         <th>offer_percent</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Offers as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->rent_id }}</td>
             <td>{{ $Student->offer_percent }}</td>
			 <td><a href="{{url('Offers',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Offers.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Offers.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Offers->links() }}
	</tbody>
 </table>
@endsection