@extends('layout/template')
@section('content')
    <h1>Offers Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">rent_id</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder={{$Offers->rent_id}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">offer_percent</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Offers->offer_percent}} readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('Offers')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
@stop