@extends('layout.template')
@section('content')
    <h1>Create Offers</h1>
    {!! Form::open(['url' => 'Offers']) !!}
	  <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('rent_id', 'rent_id:') !!}
        {!! Form::text('rent_id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('offer_percent', 'offer_percent:') !!}
        {!! Form::text('offer_percent',null,['class'=>'form-control']) !!}
    </div>
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
    {!! Form::close() !!}
@stop