@extends('layout.template')
@section('content')
    <h1>Update Offers</h1>
    {!! Form::model($Offers,['method' => 'PATCH','route'=>['Offers.update',$Offers->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('rent_id', 'rent_id:') !!}
        {!! Form::text('rent_id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('offer_percent', 'offer_percent:') !!}
        {!! Form::text('offer_percent',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
    {!! Form::close() !!}
@stop