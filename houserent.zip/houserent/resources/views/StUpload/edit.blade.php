@extends('layout.template')
@section('content')
<h1>Update Student</h1>
{!! Form::model($student,['method'=>'PATCH','route'=>['StUpload.update',$student->id],'files'=>true])!!}
<div class="form-group">
	{!!Form::label('id','id:')!!}
	{!!Form::text('id',null,['class'=>'form-control'])!!}
</div>

<div class="form-group">
	{!!Form::label('name','name:')!!}
	{!!Form::text('name',null,['class'=>'form-control'])!!}
</div>


<div class="form-group">
	{!!Form::label('class','class:')!!}
	{!!Form::text('class',null,['class'=>'form-control'])!!}
</div>

<div class="form-group">
	{!!Form::label('picture','picture:')!!}
	{!!Form::file('picture',null,['class'=>'form-control'])!!}
</div>

<div class="form-group">
	
	{!!Form::submit('Upload',['class'=>'btn btn-primary'])!!}
</div>

{!!Form::close()!!}
@stop