@extends('layout/template')
@section('content')
 <h1>Students List</h1>
 <a href="{{url('/Students/create')}}" class="btn btn-success">Create Student</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>ID</th>
         <th>Students Name</th>
         <th>Class</th>
         <th>Picture</th>
         <th colspan="4">Actions</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Students as $student)
         <tr>
             <td>{{ $student->id }}</td>
             <td>{{ $student->name }}</td>
             <td>{{ $student->class }}</td>
             <?php
             if( !file_exists( base_path()."\\public\\images\\".$student->picture) || $student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/{{ $student->picture }}' class="img-responsive" width="100px"/></td>
             <?php } ?>
			 <td><a href="{{url('Students',$student->id)}}" class="btn btn-primary">Read</a></td>
        <td><a href="{{route('StUpload.edit',$student->id)}}" class="btn btn-info">Upload</a></td>
        <td><a href="{{route('Students.edit',$student->id)}}" class="btn btn-warning">Update</a></td>
             <td>
            {!! Form::open(['method' => 'DELETE', 'route' => ['Students.destroy', $student->id]]) !!}
                {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}
                {!! Form::close() !!}
            </td>
         </tr>
     @endforeach
	</tbody>
 </table>
@endsection