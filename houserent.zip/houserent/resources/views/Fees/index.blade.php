@extends('layout/template')
@section('content')
 <h1>Total Fees store</h1>
 <a href="{{url('/Fees/create')}}" class="btn btn-success">Create Fees</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>voucherno</th>
         <th>id</th>
         <th>date</th>
         <th>amount</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Fees as $Fees)
         <tr>
             <td>{{ $Fees->voucherno }}</td>
             <td>{{ $Fees->id }}</td>
             <td>{{ $Fees->date }}</td>
             <td>{{ $Fees->amount }}</td>
			 <td><a href="{{url('Fees',$Fees->voucherno)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Fees.edit',$Fees->voucherno)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Fees.destroy',$Fees->voucherno]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
	</tbody>
 </table>
@endsection