@extends('layout/template')
@section('content')
    <h1>Fees Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">id</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder={{$Fees->voucherno}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Title</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Fees->id}} readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('Fees')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
@stop