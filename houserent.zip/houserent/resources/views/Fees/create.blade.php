@extends('layout.template')
@section('content')
    <h1>Create Fees</h1>
    {!! Form::open(['url' => 'Fees']) !!}
	  <div class="form-group">
        {!! Form::label('voucherno', 'voucherno:') !!}
        {!! Form::text('voucherno',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::select('id',$stidnames,null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('date', 'date:') !!}
        {!! Form::text('date',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('amount', 'amount:') !!}
        {!! Form::text('amount',null,['class'=>'form-control']) !!}
    </div>
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
    {!! Form::close() !!}
@stop