@extends('layout.template')
@section('content')
    <h1>Update Fees</h1>
    {!! Form::model($Fees,['method' => 'PATCH','route'=>['Fees.update',$Fees->voucherno]]) !!}
	<div class="form-group">
        {!! Form::label('voucherno', 'voucherno:') !!}
        {!! Form::text('voucherno',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('date', 'date:') !!}
        {!! Form::text('date',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('amount', 'amount:') !!}
        {!! Form::text('amount',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
    {!! Form::close() !!}
@stop