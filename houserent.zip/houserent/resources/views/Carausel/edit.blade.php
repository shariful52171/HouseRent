@extends('dashboard_layouts/dashboardtemplate')
@section('content')
<h1>Upload Student</h1>
{!! Form::model($Carausel,['method'=>'PATCH','route'=>['Carausel.update',$Carausel->id],'files'=>true])!!}
   
   



<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('title', 'title:') !!}
        {!! Form::text('title',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('category', 'category:') !!}
        {!! Form::text('category',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('location', 'location:') !!}
        {!! Form::text('location',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('picture', 'picture:') !!}
        {!! Form::file('picture',null,['class'=>'form-control']) !!}
    </div>

<div class="form-group">
	
	{!!Form::submit('Upload',['class'=>'btn btn-primary'])!!}
</div>
 <div class="form-group">
<a href="{{ url('Carausel')}}" class="btn btn-primary">Back</a>
</div>
{!!Form::close()!!}
@stop