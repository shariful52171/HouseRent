@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Carausel store</h1>
 <a href="{{url('/Carausel/create')}}" class="btn btn-success">Create Carausel</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>title</th>
         <th>category</th>
         <th>location</th>
         <th>picture</th>
         
         
       
   </tr>
     </thead>
     <tbody>
     @foreach ($Carausel  as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->title }}</td>
             <td>{{ $Student->category }}</td>
             <td>{{ $Student->location }}</td>
             <td>{{ $Student->picture }}</td>
             
             <?php
             if( !file_exists( base_path()."\\public\\carausel_images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\carausel_images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/carausel_images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\carausel_images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/carausel_images/{{ $Student->picture }}' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
            
             <td><a href="{{url('Carausel',$Student->id)}}" class="btn btn-primary">Read</a></td>
			 <td><a href="{{url('Carausel',$Student->id)}}" class="btn btn-primary">Update</a></td>
             <!-- <td><a href="{{route('Carausel.edit',$Student->id)}}" class="btn btn-warning">Update</a></td> -->
              <td><a href="{{route('Carausel.edit',$Student->id)}}" class="btn btn-info">Upload image</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE','route'=>['Carausel.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}


       

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
     
	</tbody>
 </table>
@endsection