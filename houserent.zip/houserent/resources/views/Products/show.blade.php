@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Products Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">ID</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder={{$Products->id}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Title</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Products->title}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Products->heading}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Category</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Products->category}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Description</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Products->description}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Picture</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Products->picture}} readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('Products')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
@stop