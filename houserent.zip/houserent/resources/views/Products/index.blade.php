@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 

 <h1>Total Products store</h1>
 <a href="{{url('/Products/create')}}" class="btn btn-success">Create Products</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>title</th>
         <th>heading</th>
         <th>category</th>
         <th>description</th>
         <th>picture</th>

   </tr>
     </thead>
     <tbody>
     @foreach ($Products as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->title }}</td>
             <td>{{ $Student->heading }}</td>
             <td>{{ $Student->category }}</td>
             <td>{{ $Student->description }}</td>
             <td>{{ $Student->picture }}</td>
			 <td><a href="{{url('Products',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Products.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Products.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Products->links() }}
	</tbody>
 </table>
@endsection