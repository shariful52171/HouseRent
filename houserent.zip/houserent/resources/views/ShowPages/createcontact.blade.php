@extends('Project_layouts.template')
@section('content')
    <h1>Create Contactus
</h1>
    {!! Form::open(['url' => 'store']) !!}
	  <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email', 'email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('category', 'category:') !!}
        {!! Form::text('category',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div>
   
  <div class="form-group">
        {!! Form::submit('Send', ['class' => 'btn btn-primary form-control']) !!}
    </div>
    
    {!! Form::close() !!}
@stop