@extends('layout/template')
@section('content')
 <h1>Total Comments
 store</h1>
 <a href="{{url('/Comments/create')}}" class="btn btn-success">Create Comments
</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>name</th>
         <th>email</th>
         <th>title</th>
         <th>comment</th>
         <th>active</th>
         <th>picture</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Comments as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->name }}</td>
             <td>{{ $Student->email }}</td>
             <td>{{ $Student->title }}</td>
             <td>{{ $Student->comment }}</td>
             <td>{{ $Student->active }}</td>
             <td>{{ $Student->picture }}</td>


             <?php
             if( !file_exists( base_path()."\\public\\images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/{{ $Student->picture }}' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
			
    </td>
         </tr>
     @endforeach
     
	</tbody>
 </table>
@endsection