@extends('layout.template')
@section('content')
<h1>Search Students</h1>
{!! Form::open(['url'=>'st/searchfeebyname','method'=>'get'])!!}
{!! Form::select('q', $stidnames,null, array('class' => 'form-control')) !!}
<button type="submit">Search</button>
</form>
@foreach ($Fees as $key=> $fee)
<table class="table">
<tr>
<td>
ID: {{$fee->id}}
</td>
<td>
Name:  <a href="{{ URL::route('Students.show', ['id' => $fee->id]) }}">{{$fee->name}}</a>
</td>
<td>
Class: {{$fee->class}}
</td>
<td>
Voucher No: <a href="{{ URL::route('Fees.show', ['id' => $fee->voucherno]) }}">{{$fee->voucherno}}</a>
</td>
<td>
Amount: {{$fee->amount}}
</td>
<td>
Date: {{$fee->date}}
</td>
</tr>
</table>              
@endforeach
@stop