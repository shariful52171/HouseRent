@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Category store</h1>
 <a href="{{url('/Category/create')}}" class="btn btn-success">Create Category</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Name</th>
       
   </tr>
     </thead>
     <tbody>
     @foreach ($Category as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->name }}</td>
            
			 <td><a href="{{url('Category',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Category.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Category.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Category->links() }}
	</tbody>
 </table>
@endsection