@extends('layout.template')
@section('content')
<h1>Search Students</h1>
{!! Form::open(['url'=>'st/search','method'=>'get'])!!}
<input type="text"  name="q" placeholder="Search.."/>
<button type="submit">Search</button>
</form>
@foreach ($Students as $key=> $student)
<table class="table">
<tr>
<td>
ID: {{$student->id}}
</td>
<td>
Name: <a href="{{ URL::route('Students.show', ['id' => $student->id]) }}">{{$student->name}}</a>
</td>
<td>
Class: {{$student->class}}<br/>
</td>
</tr>
</table>              
@endforeach
@stop