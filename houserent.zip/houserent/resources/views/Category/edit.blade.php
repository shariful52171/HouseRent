@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Update Category</h1>
    {!! Form::model($Category,['method' => 'PATCH','route'=>['Category.update',$Category->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('Category')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}
@stop