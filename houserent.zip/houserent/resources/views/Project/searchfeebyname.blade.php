@extends('Project_layouts.template2')

<?php 
 $footerslide1 = DB::table('carausel')->distinct()->get();

 ?>
@section('content')
<h1>Search Rent</h1>
{!! Form::open(['url'=>'pt/searchfeebyname','method'=>'get'])!!}
{!! Form::select('q', $stidnames,null, array('class' => 'form-control')) !!}
<button type="submit">Search</button>
</form>
@foreach ($category as $key=> $fee)
<table class="table">
<tr>
<td>
ID: {{$fee->id}}
</td>
<td>
City:  {{$fee->city}}</a>
</td>
<td>
Category: {{$fee->category}}
</td>
<td>
Bedrooms: {{$fee->bedrooms}}</a>
</td>
<td>
Bathrooms: {{$fee->bathrooms}}
</td>
<td>
Area: {{$fee->area}}
</td>
<td>
Face: {{$fee->face}}
</td>
<td>
Floor: {{$fee->floor}}
</td>
<td>
Lift Facility: {{$fee->liftfacility}}
</td>
<td>
Description: {{$fee->description}}
</td>

<td>
Name: {{$fee->name}}
</td>
</tr>
</table>              
@endforeach
@stop