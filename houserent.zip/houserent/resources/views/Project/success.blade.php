@extends('Project_layouts/template')
@section('content')
    <h1>Contact Show</h1>

<div class="col-sm-10" style="color: #abcdef;">
    <h1>Your message has been sent successfully.</h1>
</div>






@stop