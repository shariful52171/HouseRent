@extends('Project_layouts/template')
@section('content')

<!-- start of main area -->
    <div class="content">
        <div class="wrap">
          <div class="wrapper">
           
            <div class="con-bot">

              <hr/>

              <div>

<!-- Pic Upload -->
            <?php
             if( !file_exists( base_path()."\\public\\images\\".$showdetails->picture) || $showdetails->picture=='') { ?>
            <td>
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="100px"/>
            </td>
            <?php } else { ?>
            <td>
                <img style="border-radius: 50px" src="{{ URL::to('public/images/'.$showdetails->picture) }}" />
            </td>
            <?php } ?>
<!-- /Pic Upload -->

              </div>
            <div style="font-family: verdana; font-size: 17px">
            <div class="left col-md-6" style="float: left;">
              <br><br><b>ID:</b> {{$showdetails->id}}
              <br><br><b>City:</b> {{$showdetails->city}}
              <br><br><b>Category:</b> {{$showdetails->category}}
              <br><br><b>Bedroom:</b> {{$showdetails->bedrooms}}
              <br><br><b>Bathrooms:</b> {{$showdetails->bathrooms}}
              <br><br><b>Area:</b> {{$showdetails->area}}
              </div>
              <div class="col-md-6">
              <br><br><b>Face:</b> {{$showdetails->face}}
              <br><br><b>Floor:</b> {{$showdetails->floor}}
              <br><br><b>Lift Facility:</b> {{$showdetails->liftfacility}}
              <br><br><b>Description:</b> {{$showdetails->description}}
              <br><br><b>Picture:</b> {{$showdetails->picture}}
              </div>
            </div>              <hr/>
            

            </div>
          </div>
        </div>
    </div>      <hr>
    
              <div class="clear"></div>
            <div>
                <p class="btn btn-success" style="text-align: center;"> <a  href="{{url('/send/create')}}">Propose</a></p><br><br>
            </div>
            <div>
                <a href="{{ url('Project')}}" class="btn btn-primary">Back</a>
            </div>
<!-- end of main area -->

@endsection
