@extends('layout/template')
@section('content')
 <h1>Peru booktore</h1>
 <a href="{{url('/book/create')}}" class="btn btn-success">Create Book</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>Slno</th>
         <th>ISBN Number</th>
         <th>Book Name</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($book as $book)
         <tr>
             <td>{{ $book->slno }}</td>
             <td>{{ $book->isbn }}</td>
             <td>{{ $book->name }}</td>
			 <td><a href="{{url('book',$book->slno)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('book.edit',$book->slno)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['book.destroy',$book->slno]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
     
   
	</tbody>
 </table>
@endsection