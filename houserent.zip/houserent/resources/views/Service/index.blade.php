@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Service


 store</h1>
 <a href="{{url('service/create')}}" class="btn btn-success">Create Service

</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Title</th>
         
         <th>Description</th>
       
   </tr>
     </thead>
     <tbody>
     @foreach ($Service as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->title }}</td>
            
             <td>{{ $Student->description }}</td>
            
       <td><a href="{{url('service',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('service.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['service.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Service->links() }}
  </tbody>
 </table>
 @endsection
