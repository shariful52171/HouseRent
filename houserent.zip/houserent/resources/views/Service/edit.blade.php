@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Update Service


</h1>
    {!! Form::model($Service,['method' => 'PATCH','route'=>['service.update',$Service->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('title', 'title:') !!}
        {!! Form::text('title',null,['class'=>'form-control']) !!}
    </div>
   
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div>
    
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('service')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}
@stop