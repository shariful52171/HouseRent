@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Update Contactus
</h1>
    {!! Form::model($Contactus,['method' => 'PATCH','route'=>['contactus.update',$Contactus->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email', 'email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>
     
     <div class="form-group">
        {!! Form::label('category', 'category:') !!}
        {!! Form::text('category',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div>
    
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('contactus')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}
@stop