@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Contactus
 store</h1>
 <a href="{{url('/contactus/create')}}" class="btn btn-success">Create Contactus</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Name</th>
         <th>Email</th>
         <th>Category</th>
         <th>Description</th>
       
   </tr>
     </thead>
     <tbody>
     @foreach ($Contactus as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->name }}</td>
             <td>{{ $Student->email }}</td>
             <td>{{ $Student->category }}</td>
             <td>{{ $Student->description }}</td>
            
       <td><a href="{{url('contactus',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('contactus.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['contactus.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Contactus->links() }}
  </tbody>
 </table>
 @endsection
