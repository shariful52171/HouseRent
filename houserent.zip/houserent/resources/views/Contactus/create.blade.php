@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Create Contactus
</h1>
    {!! Form::open(['url' => 'contactSave']) !!}
	  <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email', 'email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('category', 'category:') !!}
        {!! Form::text('category',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div>
   
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('contactus')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}
@stop