@extends('layout/template')
@section('content')
 <h1>Total Students store</h1>
 <a href="{{url('/Students/create')}}" class="btn btn-success">Create Students</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>name</th>
         <th>class</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Students as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->name }}</td>
             <td>{{ $Student->class }}</td>
			 <td><a href="{{url('Students',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Students.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Students.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Students->links() }}
	</tbody>
 </table>
@endsection