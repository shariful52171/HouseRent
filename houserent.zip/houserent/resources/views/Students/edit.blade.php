@extends('layout.template')
@section('content')
    <h1>Update Students</h1>
    {!! Form::model($Students,['method' => 'PATCH','route'=>['Students.update',$Students->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('class', 'class:') !!}
        {!! Form::text('class',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
    {!! Form::close() !!}
@stop