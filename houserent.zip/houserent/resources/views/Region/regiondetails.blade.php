@extends('Project_layouts/template')
@section('content')
<link rel="stylesheet" href="<?php echo URL::to('/'); ?>/bootstrap.css">


<!-- start of main area -->
    <div class="content">
        <div class="wrap">
          <div class="wrapper">
           
<div class=""> 
  <div style="float: left;">  
@foreach ($regiondetails  as $regiondetails)
      <div class="col-md-4"> 
            <div class="con-bot">

              <hr/>

           
<!-- Pic Upload -->

            <?php
             if( !file_exists( base_path()."\\public\\images\\".$regiondetails->picture) || $regiondetails->picture=='') { ?>
            <div>
                <img src='<?php echo url("/"); ?>/public/images/cross.jpg' class="img-responsive" width="50px"/>
            </div>
            <?php } else { ?>
            <div>
                <img style="border-radius: 30px" src="{{ URL::to('public/images/'.$regiondetails->picture) }}" width="300px" height="200px"/>
            </div>
            <?php } ?>
<!-- /Pic Upload -->

          
            
            <div style="font-family: verdana; font-size: 17px">
              <br><b>ID:</b> {{$regiondetails->id}}
              <br><b>City:</b> {{$regiondetails->city}}
              <br><b>Category:</b> {{$regiondetails->category}}
              <br><b>Bedroom:</b> {{$regiondetails->bedrooms}}
              <br><b>Bathrooms:</b> {{$regiondetails->bathrooms}}
              <br><b>Area:</b> {{$regiondetails->area}}
              <br><b>Face:</b> {{$regiondetails->face}}
              <br><b>Floor:</b> {{$regiondetails->floor}}
              <br><b>Lift Facility:</b> {{$regiondetails->liftfacility}}
              <br><b>Description:</b> {{$regiondetails->description}}
              <br><b>Picture:</b> {{$regiondetails->picture}}

            </div>              <hr/>
            

            </div>
              <div class="clear"></div>
      </div>
 @endforeach
  </div>
        </div>
    </div>
    
</div>
</div>  
@endsection