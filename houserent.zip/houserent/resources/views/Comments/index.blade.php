@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Comments
 store</h1>
 <a href="{{url('/Comments/create')}}" class="btn btn-success">Create Comments
</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>name</th>
         <th>email</th>
         <th>title</th>
         <th>comment</th>
         <th>active</th>
         <th>picture</th>
   </tr>
     </thead>
     <tbody>
     @foreach ($Comments as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->name }}</td>
             <td>{{ $Student->email }}</td>
             <td>{{ $Student->title }}</td>
             <td>{{ $Student->comment }}</td>
             <td>{{ $Student->active }}</td>
             <td>{{ $Student->picture }}</td>


             <?php
             if( !file_exists( base_path()."\\public\\images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/{{ $Student->picture }}' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
			 <td><a href="{{url('Comments',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Comments.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>

              <td><a href="{{route('CommentsUpload.edit',$Student->id)}}" class="btn btn-info">Upload</a></td>
            <td>

       {!! Form::open(['method'=>'DELETE','route'=>['Comments.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
     
	</tbody>
 </table>
@endsection