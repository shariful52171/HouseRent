@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Create Comments
</h1>
    {!! Form::open(['url' => 'Comments']) !!}
	  <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
        {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email', 'email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('title', 'title:') !!}
        {!! Form::text('title',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('comment', 'comment:') !!}
        {!! Form::text('comment',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('active', 'active:') !!}
        {!! Form::text('active',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('picture', 'picture:') !!}
        {!! Form::text('picture',null,['class'=>'form-control']) !!}
    </div>
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
    <div class="form-group">
    <a href="{{ url('Comments')}}" class="btn btn-primary">Back</a>
    </div>
    {!! Form::close() !!}
@stop