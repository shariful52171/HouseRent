@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Create Rent</h1>
    {!! Form::open(['url' => 'Rent']) !!}
	  
    <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('city', 'city:') !!}
        {!! Form::text('city',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('category', 'category:') !!}
        {!! Form::text('category',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('bedrooms', 'bedrooms:') !!}
        {!! Form::text('bedrooms',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('bathrooms', 'bathrooms:') !!}
        {!! Form::text('bathrooms',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('area', 'area:') !!}
        {!! Form::text('area',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('face', 'face:') !!}
        {!! Form::text('face',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('floor', 'floor:') !!}
        {!! Form::text('floor',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('liftfacility', 'liftfacility:') !!}
        {!! Form::text('liftfacility',null,['class'=>'form-control']) !!}
    </div>
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div> <div class="form-group">
        {!! Form::label('picture', 'picture:') !!}
        {!! Form::text('picture',null,['class'=>'form-control']) !!}
    </div>
   
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('Rent')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}
@stop