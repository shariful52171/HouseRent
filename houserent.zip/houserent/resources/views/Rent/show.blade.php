@extends('dashboard_layouts/dashboardtemplate')
@section('content')
    <h1>Rent Show</h1>
<form class="form-horizontal">
   <div class="form-group">
            <label for="isbn" class="col-sm-2 control-label">ID</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="isbn" placeholder={{$Rent->id}} readonly>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">City</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="title" placeholder={{$Rent->city}} readonly>
            </div>
        </div>
         <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="{{ url('Rent')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
    </form>
@stop