@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Rent store</h1>
 <a href="{{url('/Rent/create')}}" class="btn btn-success">Create Rent</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>City</th>
         <th>Category</th>
         <th>Bedrooms</th>
         <th>Bathrooms</th>
         <th>Area</th>
         <th>Face</th>
         <th>Floor</th>
         <th>Lift Facility</th>
         <th>Description</th>
         <th>Picture</th>
      
   </tr>
     </thead>
     <tbody>
     @foreach ($Rent as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->city }}</td>
             <td>{{ $Student->category }}</td>
             <td>{{ $Student->bedrooms }}</td>
             <td>{{ $Student->bathrooms }}</td>
             <td>{{ $Student->area }}</td>
             <td>{{ $Student->face }}</td>
             <td>{{ $Student->floor }}</td>
             <td>{{ $Student->liftfacility }}</td>
             <td>{{ $Student->description }}</td>
           


             <?php
             if( !file_exists( base_path()."\\public\\images\\".$Student->picture) || $Student->picture=='') { ?>
                <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
                <img src='<?php echo url("/"); ?>/public/images/picture-02.jpg' class="img-responsive" width="100px"/></td>
                <?php } else { ?>
             <td>
<!-- <?php echo base_path()."\\public\\images\\".$Student->picture; ?><br/> -->
             <img src='<?php echo url("/"); ?>/public/images/{{ $Student->picture }}' class="img-responsive" width="100px"/></td>
             <?php } ?>
            
			 <td><a href="{{url('Rent',$Student->id)}}" class="btn btn-primary">Read</a></td>
           

             <td><a href="{{route('Rent.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            

              <td><a href="{{route('RentUpload.edit',$Student->id)}}" class="btn btn-info">Upload</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Rent.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
</div>
         </tr>
     @endforeach
      
	</tbody>
 </table>
@endsection