@extends('Project_layouts/template')
@section('content')
<br><br>
 <h1>Create Propose</h1>
    {!! Form::open(['url' => 'send']) !!}


    <div class="form-group">
        {!! Form::label('rent_id', 'Rent ID:') !!}
    {!! Form::text('rent_id',null,['class'=>'form-control']) !!}
    </div>


    
    <div class="form-group">
        {!! Form::label('name', 'name:') !!}
    {!! Form::text('name',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email', 'Email:') !!}
        {!! Form::text('email',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('contact', 'Contact:') !!}
        {!! Form::text('contact',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('description', 'Description:') !!}
        {!! Form::text('description',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Send', ['class' => 'btn btn-success ']) !!}
    </div>
    <div class="form-group">
            
                <a href="{{ url('Project')}}" class="btn btn-primary">Back</a>
           
        </div>
    {!! Form::close() !!}

@endsection
