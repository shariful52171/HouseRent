@extends('dashboard_layouts/dashboardtemplate')
@section('content')
 <h1>Total Aboutus

 store</h1>
 <a href="{{url('Aboutus/create')}}" class="btn btn-success">Create Aboutus
</a>
 <hr>
 <table class="table table-striped table-bordered table-hover">
     <thead>
     <tr class="bg-info">
         <th>id</th>
         <th>Title</th>
         
         <th>Description</th>
       
   </tr>
     </thead>
     <tbody>
     @foreach ($Aboutus as $Student)
         <tr>
             <td>{{ $Student->id }}</td>
             <td>{{ $Student->title }}</td>
            
             <td>{!! $Student->description !!}</td>
            
       <td><a href="{{url('Aboutus',$Student->id)}}" class="btn btn-primary">Read</a></td>
             <td><a href="{{route('Aboutus.edit',$Student->id)}}" class="btn btn-warning">Update</a></td>
            <td>
       {!! Form::open(['method'=>'DELETE',
       'route'=>['Aboutus.destroy',$Student->id]]) !!}

         {!! Form::submit('Delete', ['class'=>'btn btn-danger']) !!}

          {!! Form::close() !!}
    </td>
         </tr>
     @endforeach
      {{ $Aboutus->links() }}
  </tbody>
 </table>
 @endsection
