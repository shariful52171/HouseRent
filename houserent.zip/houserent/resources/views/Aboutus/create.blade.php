

<link rel="stylesheet" href="../css/normalize.css">
<link href="../dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../dashboard.css" rel="stylesheet">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="../css/froala_editor.min.css" rel="stylesheet" type="text/css">
<link href="../css/froala_style.min.css" rel="stylesheet" type="text/css">  
<link href="../carousel.css" rel="stylesheet">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="../css/froala_editor.min.css" rel="stylesheet" type="text/css">
<link href="../css/froala_style.min.css" rel="stylesheet" type="text/css">
<link href="../css/themes/dark.css" rel="stylesheet" type="text/css">

    <h1>Create Aboutus</h1>
    {!! Form::open(['url' => 'Aboutus']) !!}
	  <div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('title', 'title:') !!}
        {!! Form::text('title',null,['class'=>'form-control']) !!}
    </div>
    
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
         <textarea type="text" name="description" class="form-control" id='edit' style="margin-top: 30px;">
         
       </textarea>
    </div>
   
  <div class="form-group">
        {!! Form::submit('Save', ['class' => 'btn btn-primary form-control']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('Aboutus')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}

<script src="../dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="../assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>
   
  <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="../js/froala_editor.min.js"></script>
  <script src="../js/plugins/tables.min.js"></script>
  <script src="../js/plugins/lists.min.js"></script>
  <script src="../js/plugins/colors.min.js"></script>
  <script src="../js/plugins/media_manager.min.js"></script>
  <script src="../js/plugins/font_family.min.js"></script>
  <script src="../js/plugins/font_size.min.js"></script>
  <script src="../js/plugins/block_styles.min.js"></script>
  <script src="../js/plugins/video.min.js"></script>

  <script>
      $(function(){
          $('#edit').editable({inlineMode: false})
          $('#edit-i').editable({inlineMode: false, theme: 'dark'})
      });
  </script>


