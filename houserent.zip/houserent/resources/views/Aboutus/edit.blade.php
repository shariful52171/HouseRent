
@section('content')
<link rel="stylesheet" href="../css/normalize.css">
<link href="../dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../dashboard.css" rel="stylesheet">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="../css/froala_editor.min.css" rel="stylesheet" type="text/css">
<link href="../css/froala_style.min.css" rel="stylesheet" type="text/css">  
<link href="../carousel.css" rel="stylesheet">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="../css/froala_editor.min.css" rel="stylesheet" type="text/css">
<link href="../css/froala_style.min.css" rel="stylesheet" type="text/css">
<link href="../css/themes/dark.css" rel="stylesheet" type="text/css">

    <h1>Update Aboutus

</h1>
    {!! Form::model($Aboutus,['method' => 'PATCH','route'=>['Aboutus.update',$Aboutus->id]]) !!}
	<div class="form-group">
        {!! Form::label('id', 'id:') !!}
        {!! Form::text('id',null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('title', 'title:') !!}
        {!! Form::text('title',null,['class'=>'form-control']) !!}
    </div>
   
     <div class="form-group">
        {!! Form::label('description', 'description:') !!}
       <textarea type="text" name="description" class="form-control"  id='edit' style="margin-top: 30px;">{!! $Student->description !!}
        </textarea>
    </div>
    
    <div class="form-group">
        {!! Form::submit('Update', ['class' => 'btn btn-primary']) !!}
    </div>
     <div class="form-group">
            
                <a href="{{ url('Aboutus')}}" class="btn btn-primary">Back</a>
          
        </div>
    {!! Form::close() !!}



    
    <script src="<?php echo url("/"); ?>/dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="<?php echo url("/"); ?>/assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo url("/"); ?>/assets/js/ie10-viewport-bug-workaround.js"></script>
   
  <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/froala_editor.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/tables.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/lists.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/colors.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/media_manager.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/font_family.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/font_size.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/block_styles.min.js"></script>
  <script src="<?php echo url("/"); ?>/js/plugins/video.min.js"></script>

  <script>
      $(function(){
          $('#edit').editable({inlineMode: false})
          $('#edit-i').editable({inlineMode: false, theme: 'dark'})
      });
  </script>

@stop